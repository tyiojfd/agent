from copy import copy
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from openpyxl.utils import get_column_letter

INPUT = r'D:\python学习\baidupc\鲁迅故里景区资料整理_按大类重构_链接可点击.xlsx'
OUTPUT = r'D:\python学习\baidupc\鲁迅故里景区资料整理_最终版.xlsx'

wb = load_workbook(INPUT)

# 1) Rename core scenic spot sheet.
old_name = '02_鲁迅故里核心景点'
new_name = '02_鲁迅故里核心景点介绍'
if old_name in wb.sheetnames:
    wb[old_name].title = new_name
ws_spot = wb[new_name]

# 2) Remove Baidu-related sheet as requested.
if '06_百度相关资料' in wb.sheetnames:
    del wb['06_百度相关资料']

# 3) Add Shen Garden row to the core scenic spot introduction sheet.
headers = [ws_spot.cell(1, c).value for c in range(1, ws_spot.max_column + 1)]
row_map = {h: i + 1 for i, h in enumerate(headers)}

# Avoid duplicate if script is re-run.
existing_names = {ws_spot.cell(r, row_map.get('景点名称', 1)).value for r in range(2, ws_spot.max_row + 1)}
if '沈园' not in existing_names:
    new_row = ws_spot.max_row + 1
    values = {
        '景点名称': '沈园',
        '别名/关联': '沈氏园；绍兴鲁迅故里·沈园景区组成部分',
        '开放状态': '收费开放景点；夜间演艺以官方实时排期为准',
        '开放时间': '官方参观指南显示：白天开放时间8:00-16:40；“梦回沈园·钗头凤”沉浸式演艺开放时间18:30-21:00，18:30开始检票入园，演出19:40开始，时长约40分钟。',
        '门票价格': '沈园白天票40元/张，半价票20元/张；夜游/演艺票官方搜索摘要显示A座180元/人、C座120元/人，1.2-1.5米儿童半价、1.2米以下免费。实际票价、座位区和优惠政策以官方购票页为准。',
        '预约方式': '通过“绍兴市文旅集团”购票二维码/官方渠道进行网络实名制分时预约购买；线上购票者可刷身份证或购票二维码入园。咨询电话：0575-85135140。',
        '地点': '绍兴市越城区鲁迅中路318号，位于鲁迅故里东侧，适合与鲁迅故里核心景点联游。',
        '景区简介': '沈园又名沈氏园，原系沈氏私家花园，是绍兴著名宋式园林；园内小桥流水、亭台楼阁、景点互相映衬，是鲁迅故里·沈园景区的重要组成部分。',
        '历史简介': '沈园至今已有800多年历史，因南宋诗人陆游与唐琬的爱情故事及《钗头凤》而闻名。相传陆游与唐琬分离后在沈园重逢，陆游题写《钗头凤》，使沈园成为绍兴重要的人文景观。',
        '主要看点': '宋式园林风貌、小桥流水、亭台楼阁、《钗头凤》词壁、陆游与唐琬故事相关景观；夜间可关注“梦回沈园·钗头凤”沉浸式演艺。',
        '与鲁迅/作品关系': '沈园不是鲁迅故里核心故居遗迹，但与鲁迅故里同属“鲁迅故里·沈园景区”游览体系，地理位置相近，常作为绍兴古城人文游的联游景点。',
        '游览提示': '沈园与鲁迅故里门票/预约规则不同：鲁迅故里为免费预约参观，沈园为购票预约参观；建议同日联游时分别确认预约和开放时间。',
        '来源名称': '绍兴鲁迅故里沈园景区官网：沈园景区参观指南；绍兴市文化旅游集团官网：鲁迅故里·沈园景区；绍兴本地宝：沈园攻略补充',
        '来源链接1': 'https://sxlxmuseum.com/cgzn/syjq.htm',
        '来源链接2': 'https://www.shaoxingtour.cn/rwjq/lxgl_syjq.htm',
        '来源链接3': 'https://sx.bendibao.com/jingdian/shenyuan/',
        '来源链接4': '',
    }
    for header, value in values.items():
        if header in row_map:
            ws_spot.cell(new_row, row_map[header]).value = value
    # Copy style from previous data row.
    template_row = new_row - 1
    for col in range(1, ws_spot.max_column + 1):
        src = ws_spot.cell(template_row, col)
        dst = ws_spot.cell(new_row, col)
        if src.has_style:
            dst._style = copy(src._style)
        dst.alignment = Alignment(vertical='top', wrap_text=True)

# 4) Make URL cells highly reliable in Excel: use HYPERLINK formulas with readable text,
#    and add raw URL note if users need to copy manually. This avoids the "multiple URLs in one cell" problem
#    and works in WPS/Excel better than plain hyperlink objects in some environments.
def excel_quote(s: str) -> str:
    return s.replace('"', '""')

for ws in wb.worksheets:
    if ws.max_row < 2:
        continue
    headers = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
    for col, header in enumerate(headers, start=1):
        if header is None:
            continue
        header_str = str(header)
        is_link_col = header_str.startswith('来源链接') or header_str in {'URL', '链接'}
        if not is_link_col:
            continue
        for row in range(2, ws.max_row + 1):
            cell = ws.cell(row, col)
            url = None
            # If previous version stored a hyperlink and display text, take the actual target.
            if cell.hyperlink and cell.hyperlink.target:
                url = cell.hyperlink.target
            elif isinstance(cell.value, str) and cell.value.startswith('http'):
                url = cell.value.strip()
            elif isinstance(cell.value, str) and cell.value.startswith('=HYPERLINK('):
                # Already formula; leave as-is.
                continue
            if url:
                label = '打开链接' if header_str in {'URL', '链接'} else header_str.replace('来源', '打开')
                cell.value = f'=HYPERLINK("{excel_quote(url)}","{excel_quote(label)}")'
                cell.hyperlink = None
                cell.comment = None
                cell.font = Font(color='0563C1', underline='single')
                cell.alignment = Alignment(vertical='top', wrap_text=True)

    # Apply autofilter and basic layout. Remove stale tables if any remain after prior modifications.
    try:
        ws.tables.clear()
    except Exception:
        pass
    if ws.max_row > 1 and ws.max_column > 1:
        ws.auto_filter.ref = ws.dimensions
    ws.sheet_view.showGridLines = False
    for col in range(1, ws.max_column + 1):
        letter = get_column_letter(col)
        header = ws.cell(1, col).value
        if header and (str(header).startswith('来源链接') or str(header) in {'URL', '链接'}):
            ws.column_dimensions[letter].width = 16
        elif col <= 2:
            ws.column_dimensions[letter].width = max(ws.column_dimensions[letter].width or 12, 18)
        else:
            ws.column_dimensions[letter].width = max(min(ws.column_dimensions[letter].width or 45, 65), 20)

# 5) Update cover sheet text if present.
if '00_使用说明' in wb.sheetnames:
    ws = wb['00_使用说明']
    for row in range(1, ws.max_row + 1):
        if ws.cell(row, 1).value == '文件名':
            ws.cell(row, 2).value = '鲁迅故里景区资料整理_最终版.xlsx'
        if ws.cell(row, 1).value == '大类结构':
            ws.cell(row, 2).value = '景区总览；鲁迅故里核心景点介绍；活动；鲁迅生平；实用信息；来源清单；抓取清理说明。'

wb.save(OUTPUT)
print(OUTPUT)
print('|'.join(wb.sheetnames))
# verify formulas in link columns
count = 0
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for cell in row:
            if isinstance(cell.value, str) and cell.value.startswith('=HYPERLINK('):
                count += 1
print('hyperlink formulas:', count)
