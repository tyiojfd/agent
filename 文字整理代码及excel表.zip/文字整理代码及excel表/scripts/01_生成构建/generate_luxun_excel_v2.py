from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

OUTPUT = '鲁迅故里景区资料整理_按大类重构.xlsx'
SCRAPE_DATE = '2026-06-13'

sources = {
    'official_intro': ('绍兴鲁迅故里沈园景区官网：景区介绍', 'https://sxlxmuseum.com/jqjs.htm', '官方'),
    'official_visit': ('绍兴鲁迅故里沈园景区官网：鲁迅故里参观指南', 'https://sxlxmuseum.com/cgzn/lxgl.htm', '官方'),
    'sx_tour_area': ('绍兴市文化旅游集团官网：鲁迅故里·沈园景区', 'https://www.shaoxingtour.cn/rwjq/lxgl_syjq.htm', '官方/文旅集团'),
    'sx_tour_lxgl': ('绍兴市文化旅游集团官网：绍兴鲁迅故里景区', 'https://www.shaoxingtour.cn/info/1031/1260.htm', '官方/文旅集团'),
    'sx_tour_museum': ('绍兴市文化旅游集团官网：绍兴鲁迅纪念馆', 'https://www.shaoxingtour.cn/info/1031/1259.htm', '官方/文旅集团'),
    'sx_tour_sanwei': ('绍兴市文化旅游集团官网：三味书屋（寿家台门）', 'https://www.shaoxingtour.cn/info/1031/1257.htm', '官方/文旅集团'),
    'sx_tour_guzhai': ('绍兴市文化旅游集团官网：鲁迅故居（周家新台门）', 'https://www.shaoxingtour.cn/info/1031/1261.htm', '官方/文旅集团'),
    'sanwei_activity': ('绍兴鲁迅故里沈园景区官网：三味早读', 'https://sxlxmuseum.com/info/1004/1013.htm', '官方'),
    'shexi_activity': ('绍兴鲁迅故里沈园景区官网：水乡社戏', 'https://sxlxmuseum.com/info/1004/1005.htm', '官方'),
    'shaoxing_news_hours': ('绍兴网：鲁迅故里景区开放时间调整公告', 'https://www.shaoxing.com.cn/p/3384879.html', '地方媒体/公告转载'),
    'sx_gov_traffic': ('绍兴市政府相关页面：附近地铁与公交信息', 'https://www.sx.gov.cn/art/2024/7/3/art_1229365388_59542165.html', '政府信息'),
    'zj_ct': ('浙江省文化和旅游厅：Lu Xun Native Place', 'https://ct.zj.gov.cn/art/2019/8/5/art_1672758_36392457.html', '政府文旅'),
    'bendibao': ('绍兴本地宝：鲁迅故里游玩攻略', 'https://sx.bendibao.com/tour/2023621/20696.shtm', '本地生活/攻略'),
    'baidu_exp': ('百度经验：鲁迅故里简介', 'https://jingyan.baidu.com/article/7082dc1c12e154a50a89bd84.html', '百度系/第三方经验'),
    'baike_tashuo_scenic': ('百度百科TA说：鲁迅故里景区相关介绍', 'https://wapbaike.baidu.com/tashuo/browse/content?id=c88e91fe52b9171a8590dbcf', '百度系/百科TA说'),
    'baike_tashuo_museum': ('百度百科TA说：绍兴鲁迅故里：鲁迅纪念馆', 'https://wapbaike.baidu.com/tashuo/browse/content?id=eba29de29a18b9c00314e06a', '百度系/百科TA说'),
    'baike_tashuo_text': ('百度百科TA说：鲁迅《从百草园到三味书屋》相关介绍', 'https://wapbaike.baidu.com/tashuo/browse/content?id=69372428caa32b08a038476e', '百度系/百科TA说'),
    'luxun_shanghai': ('上海鲁迅纪念馆：鲁迅知识', 'https://www.luxunmuseum.cn/study/index.html', '官方纪念馆/鲁迅知识'),
    'sxlz_museum': ('绍兴市廉政文化相关政务页：鲁迅纪念馆', 'https://sxlz.sx.gov.cn/art/2022/11/14/art_1229701440_58924111.html', '政务/纪念馆介绍'),
    'xianheng': ('绍兴咸亨集团：咸亨酒店信息', 'https://www.xianheng.com/index.php?a=lists&c=index&catid=151&m=content', '企业官方'),
    'ctrip_food': ('携程美食：咸亨酒店菜品参考', 'https://you.ctrip.com/food/18/7833129.html', '旅游平台'),
    'klook_hotel': ('Klook酒店页：鲁迅故里沈园周边住宿参考', 'https://www.klook.com/zh-CN/hotels/detail/1993761-shaoxing-dayue-xiaoyuan-culture-theme-hotel-lu-xuns-hometown-shenyuan-branch/', '旅游平台'),
    'huazhu_hotel': ('华住会：汉庭绍兴鲁迅故里酒店', 'https://m.huazhu.com/Hotel/Detail/9019177', '酒店官方平台'),
    'amap_bus': ('高德地图：鲁迅故里公交站信息', 'https://www.amap.com/place/BV10198907', '地图平台'),
}

def src(keys):
    return '；'.join(sources[k][0] for k in keys), '；'.join(sources[k][1] for k in keys)

# 01 景区总览
overview_rows = []
def add_overview(item, content, keys, note=''):
    sname, surl = src(keys)
    overview_rows.append(['景区总览', item, content, sname, surl, note])

add_overview('景区名称', '鲁迅故里景区/绍兴鲁迅故里景区，鲁迅故里·沈园景区的重要组成部分。', ['official_intro','sx_tour_lxgl'])
add_overview('地理位置', '浙江省绍兴市越城区鲁迅中路235号一带；官方参观指南描述为解放路、中兴路与鲁迅路交叉口附近。', ['official_visit','sx_tour_lxgl','zj_ct'])
add_overview('总体定位', '鲁迅先生诞生和青少年时期生活过的故土，是绍兴市区保存完好、具文化内涵和水城经典风貌的历史街区。', ['official_intro','sx_tour_lxgl','sx_tour_area'])
add_overview('景区等级/荣誉', '国家AAAAA级旅游景区、全国重点文物保护单位、全国爱国主义教育基地/示范基地、全国红色旅游经典景区、全国中小学生研学实践教育基地、首批“全国研学旅游示范基地”之一。', ['official_intro','sx_tour_lxgl','sx_tour_area'])
add_overview('景区面积', '绍兴市文化旅游集团资料称，绍兴鲁迅故里景区占地约28.9万平方米。', ['sx_tour_lxgl'])
add_overview('核心组成', '鲁迅故居、百草园、三味书屋、鲁迅祖居、绍兴鲁迅纪念馆、鲁迅笔下风情园等。', ['official_visit','sx_tour_lxgl','sx_tour_area'])
add_overview('文化价值', '通过与鲁迅生平、童年记忆和文学作品密切相关的人文古迹，解读鲁迅作品、品味鲁迅笔下风物、感受鲁迅当年生活情境。', ['sx_tour_area','sx_tour_lxgl'])
add_overview('历史沿革', '绍兴鲁迅纪念馆始建于1953年；百度经验资料称2003年鲁迅故里保护工程竣工，2008年6月起鲁迅纪念馆实行“文化惠民”免费开放，2012年鲁迅故里和沈园景区联手成为5A级景区。', ['sx_tour_area','baidu_exp'], '百度经验内容作为辅助线索，现行参观规则以官方公告为准。')
add_overview('适合人群', '亲子研学、语文课文主题游、鲁迅文学爱好者、绍兴古城文化游、红色旅游/爱国主义教育团队。', ['sx_tour_lxgl','sx_tour_area'])

common_open = '执行鲁迅故里景区统一开放规则：周一8:30-17:00（16:30停止预约、16:45停止入园）；周二至周日8:30-21:00（20:00停止预约、20:30停止入园）；黄金周/小长假8:30-22:30（21:30停止预约、22:00停止入园）。'
common_ticket = '官方提示通过官方渠道免费预约，勿购买非官方渠道门票；如遇特殊展陈/活动，以官方实时公告为准。'
common_booking = '关注“绍兴市文旅集团”或“绍兴鲁迅纪念馆”官方微信账号分时预约；预约成功后，在预约时段内凭身份证或人脸识别进入；每个手机号每天一次、每次最多5人。'

# 02 鲁迅故里核心景点
spot_rows = []
def add_spot(name, alias, loc, intro, history, highlights, relation, tips, keys, status='开放景点（以官方实时公告为准）'):
    sname, surl = src(keys + ['official_visit'] if 'official_visit' not in keys else keys)
    spot_rows.append([name, alias, status, common_open, common_ticket, common_booking, loc, intro, history, highlights, relation, tips, sname, surl])

add_spot('鲁迅故里景区', '绍兴鲁迅故里景区', '绍兴市越城区鲁迅中路235号一带', '绍兴市区保存完好、文化内涵丰富、体现水城经典风貌的历史街区，是鲁迅出生和成长的故地。', '鲁迅诞生并度过青少年时期的故土；景区保护和展示鲁迅故居、祖居、求学场所及相关街区风貌。', '整体街区、台门建筑、水乡风貌、鲁迅作品场景、纪念馆陈列、研学活动。', '集中呈现鲁迅童年、家族生活、求学经历及其作品中的绍兴风物。', '首次游览建议先看总览，再按祖居—三味书屋—故居/百草园—风情园—纪念馆动线游览。', ['official_intro','sx_tour_lxgl','sx_tour_area'])
add_spot('鲁迅故居', '周家新台门', '绍兴城内东昌坊口；与百草园相连', '周家新台门是鲁迅出生和青少年生活的重要居所，坐北朝南，青瓦粉墙，砖木结构。', '建于清嘉庆年间，是周氏家族三个台门中建成较晚者。1881年9月25日鲁迅出生于此，并生活到18岁去南京求学；后回乡任教也基本居住于此。新台门共分六进，大小房屋80余间，连同百草园占地4000余平方米。', '台门建筑、鲁迅家庭生活空间、与百草园相连的童年场景。', '理解鲁迅家庭背景、绍兴传统大家族居住空间和鲁迅早年生活经验的关键地点。', '与百草园连看，适合对照《从百草园到三味书屋》。', ['sx_tour_guzhai','sx_tour_area'])
add_spot('百草园', '新台门周家菜园', '鲁迅故居后面', '百草园原为新台门周氏族人共有菜园，是鲁迅幼时经常游戏玩耍的地方。', '占地近2000平方米，平时种瓜菜，秋后晒稻谷。鲁迅成年后写《从百草园到三味书屋》回忆此地；文中提及的泥墙根和石井至今保存完好。', '泥墙根、石井、菜园空间、鲁迅童年“乐园”的文学场景。', '《从百草园到三味书屋》的核心现实场景之一。', '适合亲子和研学讲解，可结合课文中的自然观察和童年记忆。', ['sx_tour_area','baidu_exp'])
add_spot('三味书屋', '寿家台门东侧厢房', '寿家台门内，前临小河，与周家老台门隔河相望', '三味书屋是当时绍兴城中有名私塾，鲁迅12岁至17岁在此读书。', '寿家台门建于清嘉庆年间；三味书屋约35平方米，正中悬清代书法家梁同书所题“三味书屋”匾额，匾下挂《松鹿图》，保留塾师讲台、学生座位等传统私塾陈设。', '三味书屋匾额、《松鹿图》、私塾课桌椅、后面小园。', '对应《从百草园到三味书屋》中关于求学空间的描写，体现鲁迅早年传统教育经历。', '室内空间较小，旺季建议错峰；注意不要触碰文物陈设。', ['sx_tour_sanwei','sx_tour_area'])
add_spot('鲁迅祖居', '周家老台门', '鲁迅故里景区内，与三味书屋隔河相望区域', '鲁迅祖居又称周家老台门，是周氏祖先居住地，展示鲁迅家族世系、绍兴台门建筑和传统家族生活。', '周家老台门是周氏家族重要祖居空间，与周家新台门、寿家台门共同构成鲁迅故里传统台门建筑群。', '传统台门格局、家族生活展示、祖居空间。', '帮助理解鲁迅家族背景及绍兴传统士绅家庭生活。', '可与鲁迅故居合并讲解“祖居—故居”的家族空间关系。', ['sx_tour_area','official_visit'])
add_spot('绍兴鲁迅纪念馆', '鲁迅生平事迹陈列相关空间', '鲁迅故里东侧；东接鲁迅祖居，西邻周家新台门，北毗朱家台门，南临东昌坊口', '绍兴鲁迅纪念馆始建于1953年，是展示鲁迅生平业绩及其与故乡绍兴渊源关系的重要纪念性人物博物馆。', '2003年前后为恢复鲁迅故里传统风貌，原与环境尺度不协调的陈列厅被拆除，新建纪念馆以“老房子、新空间”理念融入传统街巷肌理；总占地约6000平方米，总建筑面积约5000平方米。', '鲁迅生平事迹陈列、鲁迅与绍兴渊源、台门式建筑外观。', '系统了解鲁迅思想、文学创作、生平经历与绍兴文化背景。', '官方参观指南抓取时标注“鲁迅纪念馆（封闭提升中）”，参观前务必查看最新公告。', ['sx_tour_area','sx_tour_museum'], status='官方参观指南抓取时标注“封闭提升中”，以实时公告为准')
add_spot('鲁迅笔下风情园', '朱家台门', '百草园旁', '朱家台门修缮后辟为鲁迅笔下风情园，是古城保存较完整的典型花园式台门。', '资料称朱家台门原为越王望花宫故址，系明初名将胡大海官宅的一部分；清宣统元年绍兴名士程柏堂曾题石。', '百年罗汉松、盘槐、红梅、绿萼梅等花木，约400平方米水池，花园式台门风貌。', '补充呈现鲁迅笔下绍兴风情、台门园林和水乡生活图景。', '17:00以后部分假山、水域等区域可能因安全需要关闭。', ['sx_tour_area','official_visit'])
add_spot('鲁迅故里步行街/风情街', '鲁迅中路历史街区商业与游览空间', '鲁迅中路及核心景点周边', '依托鲁迅故里历史街区形成的步行游览和商业体验空间，可串联景点、文创、小吃、黄酒和咸亨酒店等。', '街区以鲁迅故里历史文化资源和绍兴古城风貌为基础发展旅游服务。', '绍兴小吃、黄酒体验、文创、古城街巷氛围。', '作为鲁迅故里游览外延，连接文学记忆、绍兴地方生活和当代旅游消费。', '商业信息变化快，建议以现场与地图为准；不要把商户宣传当作史实。', ['sx_tour_lxgl','xianheng','ctrip_food'])

# 03 活动
activity_rows = []
def add_activity(name, loc, time_info, content, meaning, audience, keys, note=''):
    sname, surl = src(keys)
    activity_rows.append([name, loc, time_info, content, meaning, audience, sname, surl, note])

add_activity('三味早读', '三味书屋旁“三余书屋”/鲁迅故里相关研学空间', '以景区活动排期为准', '游客可体验旧时私塾早读情景，感受传统启蒙教育方式。', '对应鲁迅在三味书屋读书经历，适合把课文场景转化为沉浸式体验。', '亲子、学生研学、语文主题团队', ['sanwei_activity','sx_tour_lxgl'])
add_activity('水乡社戏', '鲁迅笔下风情园内', '以景区演出排期为准', '在江南水乡特色戏台观看绍兴地方戏等表演。', '呼应鲁迅作品中的水乡社戏与绍兴地方戏曲文化。', '普通游客、亲子、研学团队', ['shexi_activity','sx_tour_lxgl'])
add_activity('绍俗祝福', '鲁迅祖居德寿堂等相关空间', '通常春节期间举行，具体以公告为准', '演示鲁迅笔下“绍兴祝福”相关年俗仪式，寓意迎接福神、祈求平安顺遂。', '展示绍兴传统年俗和鲁迅作品中的地方文化背景。', '春节游客、民俗文化兴趣者、研学团队', ['sx_tour_area'])
add_activity('鲁迅故里研学游', '鲁迅故里核心景点及研学空间', '以景区研学产品安排为准', '包含鲁迅作品展示课、历史文化体验课、三味早读情景课等。', '把鲁迅作品、故居实景、绍兴历史文化结合，形成系统研学课程。', '中小学生、亲子、学校团队', ['sx_tour_lxgl','sx_tour_area'])
add_activity('版画拓印/木刻藏书票互动', '景区研学活动空间', '以活动安排为准', '景区研学活动引入版画拓印、木刻藏书票等趣味互动项目。', '关联鲁迅对木刻版画的倡导与现代文学艺术教育。', '学生、亲子、文创体验游客', ['sx_tour_lxgl'])
add_activity('祝福大典/祝福主题体验', '鲁迅祖居及景区相关区域', '节庆活动，具体以官方公告为准', '部分攻略或游客口径称“祝福大典”，官方资料中更常见名称为“绍俗祝福”。', '以鲁迅作品与绍兴年俗为线索，形成节庆文化体验。', '春节及节庆游客', ['sx_tour_area','bendibao'], '建议正式写作中优先使用官方名称“绍俗祝福”。')

# 04 鲁迅生平
life_rows = []
def add_life(period, time_range, place, event, relation, keys, note=''):
    sname, surl = src(keys)
    life_rows.append([period, time_range, place, event, relation, sname, surl, note])

add_life('出生与童年', '1881年9月25日', '浙江绍兴；周家新台门', '鲁迅出生于绍兴周家新台门。', '对应鲁迅故居，是鲁迅故里景区最核心的生平发生地。', ['sx_tour_guzhai','luxun_shanghai'])
add_life('绍兴生活', '1881年-约1898年', '绍兴鲁迅故里一带', '鲁迅在绍兴生活至18岁去南京求学，童年和少年经历构成其后来文学创作的重要记忆资源。', '鲁迅故居、百草园、三味书屋等景点集中呈现这一时期生活与求学空间。', ['sx_tour_guzhai','sx_tour_area'])
add_life('童年游玩', '少年时期', '百草园', '百草园是鲁迅幼时经常游戏玩耍之处，成年后写入《从百草园到三味书屋》。', '对应百草园景点和语文课文主题游。', ['sx_tour_area','baidu_exp'])
add_life('私塾求学', '约12岁至17岁', '三味书屋', '鲁迅12岁至17岁在三味书屋读书，学习传统经典和古典文学，同时阅读课外书。', '对应三味书屋，体现其早年教育经历。', ['sx_tour_sanwei','sx_tour_area'])
add_life('离乡求学', '18岁后', '南京等地', '鲁迅18岁离开绍兴去南京求学。', '景区叙事常以“离开故乡”作为绍兴青少年时期的节点。', ['sx_tour_guzhai'])
add_life('鲁迅与绍兴', '一生相关', '绍兴/故乡记忆', '绍兴的家族、台门、水乡、民俗和童年经验长期影响鲁迅创作。', '鲁迅故里通过旧居、祖居、私塾、菜园、风情园等实景帮助理解鲁迅与故乡关系。', ['sx_tour_museum','sx_tour_lxgl'])
add_life('逝世', '1936年10月19日', '上海', '上海鲁迅纪念馆资料显示，鲁迅于1936年10月19日在上海大陆新村9号寓所病逝。', '作为鲁迅生平终点，可与纪念馆生平陈列衔接。', ['luxun_shanghai'])
add_life('纪念与研究', '1953年至今', '绍兴鲁迅纪念馆', '绍兴鲁迅纪念馆始建于1953年，承担鲁迅生平事迹展示、爱国主义教育及相关文化传播功能。', '景区内纪念馆系统呈现鲁迅一生业绩及其与故乡绍兴的渊源。', ['sx_tour_museum','sxlz_museum'])

# 05 实用信息
practical_rows = []
def add_practical(cat, item, content, advice, keys, note=''):
    sname, surl = src(keys)
    practical_rows.append([cat, item, content, advice, sname, surl, note])

add_practical('开放预约', '开放时间', common_open, '节假日、特殊活动、极端天气可能调整，出行前查官方公告。', ['official_visit','shaoxing_news_hours'])
add_practical('开放预约', '门票价格', common_ticket, '不要购买非官方渠道门票。', ['official_visit'])
add_practical('开放预约', '预约方式', common_booking, '家庭/团队超过5人需提前安排多个实名手机号预约。', ['official_visit'])
add_practical('开放预约', '开放景点', '官方参观指南列出鲁迅祖居、三味书屋、鲁迅纪念馆（抓取时标注封闭提升中）、鲁迅故居、百草园、鲁迅笔下风情园；17:00以后部分假山、水域等区域关闭。', '纪念馆是否开放务必以实时公告为准。', ['official_visit'])
add_practical('咨询', '咨询电话', '0575-85132080；绍兴市文化旅游集团页面另列旅游咨询电话0575-85081706。', '以官方最新公示为准。', ['official_visit','sx_tour_lxgl'])
add_practical('交通', '地址', '浙江省绍兴市越城区鲁迅中路235号一带。', '导航可搜“鲁迅故里”或“绍兴鲁迅故里景区”。', ['official_visit','sx_tour_lxgl','zj_ct'])
add_practical('交通', '地铁', '绍兴轨道交通1号线“鲁迅故里站”临近景区，绍兴市政府页面显示步行约290米可达。', '公共交通优先，古城核心区节假日停车压力较大。', ['sx_gov_traffic'])
add_practical('交通', '公交', '可搜索“鲁迅故里”“塔山（地铁鲁迅故里站）”等站点。地图检索显示多条公交线路途经，包括8、13、24、30、52、68、88、111、177路及古城公交接驳专线等。', '线路可能调整，出发当天以地图/公交APP为准。', ['amap_bus','sx_gov_traffic'])
add_practical('交通', '自驾停车', '鲁迅故里位于古城核心区，节假日人流车流集中；本地攻略提到可关注绍兴古城停车场等周边停车资源。', '建议提前查停车场余位并错峰。', ['bendibao'])
add_practical('住宿', '推荐住宿区域', '鲁迅中路、马园弄、沈园、人民路、解放路、仓桥直街一带，便于步行串联鲁迅故里、沈园、古城街区和餐饮。', '首次到绍兴建议住鲁迅故里/沈园周边；想兼顾夜游和餐饮可考虑仓桥直街/人民路周边。', ['klook_hotel','huazhu_hotel'])
add_practical('住宿', '酒店示例', '绍兴大越小院文化主题酒店（鲁迅故里沈园店）页面显示距鲁迅故里约300米；汉庭绍兴鲁迅故里酒店页面显示距鲁迅故里、沈园步行约7分钟。', '示例只作地理参考，实际以实时房价、评价、房态为准。', ['klook_hotel','huazhu_hotel'])
add_practical('美食', '绍兴风味', '可体验绍兴黄酒、茴香豆、炸臭豆腐、梅干菜扣肉、醉鸡、生醉河虾、熏鱼、油焖笋、醉鱼干等。', '部分菜品含酒或味道偏咸鲜，按个人口味选择。', ['ctrip_food','xianheng'])
add_practical('美食', '咸亨酒店', '咸亨集团资料显示，咸亨酒店创始于1894年，地址为绍兴市鲁迅中路179号。', '可与鲁迅故里游览结合，高峰期可能排队。', ['xianheng','ctrip_food'])
add_practical('游览路线', '2-3小时核心线', '鲁迅祖居—三味书屋—鲁迅故居—百草园—鲁迅笔下风情园—绍兴鲁迅纪念馆（如开放）。', '适合课文主题游和第一次到访。', ['sx_tour_area','official_visit'])
add_practical('游览路线', '半天/一天线', '上午鲁迅故里核心景点，中午鲁迅中路或咸亨酒店周边用餐，下午沈园或仓桥直街，晚上可安排古城散步。', '节假日需更早预约并预留排队时间。', ['bendibao','xianheng'])
add_practical('文明安全', '参观注意', '景区为无烟景区；请勿挪动展品，爱护公共设施；禁止嬉水、攀爬假山树木；严禁携带宠物入园。', '儿童、行动不便老人需陪同。', ['official_visit'])

# 06 百度相关资料
baidu_rows = [
    ['百度经验', '鲁迅故里简介', '页面概述鲁迅故里位于浙江省绍兴市鲁迅中路；1953年1月绍兴鲁迅纪念馆成立；2003年保护工程竣工；2008年6月起免费开放；并分述百草园、三味书屋、鲁迅祖居。', sources['baidu_exp'][1], '作为百度系资料纳入；与官方来源交叉核验后使用。'],
    ['百度经验', '百草园摘录', '称百草园在鲁迅故居后面，占地近2000平方米，原为新台门周姓住户共有菜园，主要部分仍基本保持原样。', sources['baidu_exp'][1], '与绍兴文旅集团页面一致。'],
    ['百度经验', '三味书屋摘录', '称三味书屋是绍兴城内私塾，鲁迅12岁开始到此读书，前后约五年，书屋约35平方米，匾额为清代书法家梁同书所题。', sources['baidu_exp'][1], '与绍兴文旅集团三味书屋页一致。'],
    ['百度经验', '鲁迅祖居摘录', '称鲁迅祖居为周家老台门，坐北朝南，前临东昌坊口，后通咸欢河，西接戴家台门，与三味书屋隔河相望。', sources['baidu_exp'][1], '具体空间描述作补充，建议以现场导览为准。'],
    ['百度百科TA说', '鲁迅故里景区相关介绍', '搜索结果显示该页描述鲁迅故里景区为鲁迅少年时生活、学习相关场所，涉及鲁迅故居、百草园、三味书屋等。', sources['baike_tashuo_scenic'][1], '抓取时遇到百度验证页，未完整抽取正文；作为检索来源记录。'],
    ['百度百科TA说', '绍兴鲁迅故里：鲁迅纪念馆', '搜索结果显示该页介绍绍兴鲁迅故里是鲁迅青少年时期生活过的故土，包含鲁迅故居、鲁迅祖居、百草园、三味书屋等相关内容。', sources['baike_tashuo_museum'][1], '抓取受限，仅保留搜索结果摘要。'],
    ['百度百科TA说', '从百草园到三味书屋相关', '搜索结果显示该页围绕鲁迅散文《从百草园到三味书屋》背景，涉及百草园、三味书屋和鲁迅童年经历。', sources['baike_tashuo_text'][1], '用于文学背景线索；事实以官方景区页核验。'],
]

# 07 来源清单
source_rows = []
for i, (key, (name, url, typ)) in enumerate(sources.items(), start=1):
    if key in ['official_intro','official_visit','sx_tour_area','sx_tour_lxgl','sx_tour_museum','sx_tour_sanwei','sx_tour_guzhai','sanwei_activity','shexi_activity']:
        reliability = '高：官方/文旅集团页面，作为主要事实来源'
    elif key in ['sx_gov_traffic','zj_ct','shaoxing_news_hours','sxlz_museum','luxun_shanghai']:
        reliability = '较高：政府/地方媒体/纪念馆信息'
    elif key.startswith('baidu'):
        reliability = '中：百度系内容，作为补充或线索，已尽量与官方交叉核验'
    else:
        reliability = '中：旅游/地图/企业平台，适合补充交通、住宿、美食等动态信息'
    source_rows.append([i, name, typ, url, reliability])

cleaning_rows = [
    ['重构依据', '按用户要求将大类调整为：景区总览、鲁迅故里核心景点、活动、鲁迅生平、实用信息，并保留百度相关资料、来源清单和清理说明。'],
    ['核心景点字段', '每个核心景点均包含开放时间、门票价格、预约方式、地点、景区简介、历史简介、主要看点、与鲁迅/作品关系、游览提示、来源。'],
    ['清理规则', '删除网页导航、版权栏、重复标题、广告推荐、无关景点内容；保留可核验的时间、地点、名称、面积、历史节点、开放规则等事实信息。'],
    ['来源优先级', '官方景区官网、绍兴市文化旅游集团官网、政府/纪念馆信息优先；百度经验/百度百科TA说、旅游平台用于补充，并在备注中标明。'],
    ['时效提示', f'本表整理日期为{SCRAPE_DATE}。开放时间、预约规则、纪念馆开放状态、公交线路、酒店房态和商户菜单均可能变化，出行前应复核官方公众号、官网或实时地图/预订平台。'],
]

wb = Workbook()
wb.remove(wb.active)

def add_sheet(title, headers, rows):
    ws = wb.create_sheet(title)
    ws.append(headers)
    for row in rows:
        ws.append(row)
    header_fill = PatternFill('solid', fgColor='1F4E78')
    header_font = Font(color='FFFFFF', bold=True)
    thin = Side(style='thin', color='D9E2F3')
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = Border(top=thin, left=thin, right=thin, bottom=thin)
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical='top', wrap_text=True)
            cell.border = Border(top=thin, left=thin, right=thin, bottom=thin)
    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = ws.dimensions
    for col_idx in range(1, ws.max_column + 1):
        letter = get_column_letter(col_idx)
        max_len = 0
        for cell in ws[letter]:
            value = '' if cell.value is None else str(cell.value)
            max_len = max(max_len, min(len(value), 90))
        if col_idx >= 3:
            width = min(max(max_len + 2, 18), 62)
        else:
            width = min(max(max_len + 2, 12), 32)
        ws.column_dimensions[letter].width = width
    ws.sheet_view.showGridLines = False
    if ws.max_row > 1 and ws.max_column > 1:
        ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"
        display_name = 'T_' + ''.join(ch if ch.isalnum() else '_' for ch in ws.title)[:20]
        table = Table(displayName=display_name, ref=ref)
        table.tableStyleInfo = TableStyleInfo(name='TableStyleMedium2', showFirstColumn=False, showLastColumn=False, showRowStripes=True, showColumnStripes=False)
        ws.add_table(table)
    return ws

cover = wb.create_sheet('00_使用说明')
for row in [
    ['文件名', OUTPUT],
    ['整理主题', '鲁迅故里景区（绍兴）文字信息抓取、清理与分类整理——按用户指定大类重构版'],
    ['整理日期', SCRAPE_DATE],
    ['大类结构', '景区总览；鲁迅故里核心景点；活动；鲁迅生平；实用信息；百度相关资料；来源清单；抓取清理说明。'],
    ['重要提示', '开放时间、预约规则、纪念馆是否开放、公交线路、酒店房态和餐饮菜单会变化；实际出行请以官方公众号/官网及实时平台为准。'],
]:
    cover.append(row)
for row in cover.iter_rows():
    for cell in row:
        cell.alignment = Alignment(vertical='top', wrap_text=True)
cover['A1'].font = Font(bold=True)
cover.column_dimensions['A'].width = 16
cover.column_dimensions['B'].width = 110
cover.sheet_view.showGridLines = False

add_sheet('01_景区总览', ['大类','项目','内容','来源名称','来源链接','备注'], overview_rows)
add_sheet('02_鲁迅故里核心景点', ['景点名称','别名/关联','开放状态','开放时间','门票价格','预约方式','地点','景区简介','历史简介','主要看点','与鲁迅/作品关系','游览提示','来源名称','来源链接'], spot_rows)
add_sheet('03_活动', ['活动名称','地点','时间/频次','活动内容','文化意义','适合人群','来源名称','来源链接','备注'], activity_rows)
add_sheet('04_鲁迅生平', ['阶段','时间','地点','生平事件','与景区/展陈关系','来源名称','来源链接','备注'], life_rows)
add_sheet('05_实用信息', ['类别','项目','内容','建议','来源名称','来源链接','备注'], practical_rows)
add_sheet('06_百度相关资料', ['百度来源类型','主题','整理内容','链接','处理备注'], baidu_rows)
add_sheet('07_来源清单', ['序号','来源名称','来源类型','URL','可信度/使用说明'], source_rows)
add_sheet('08_抓取清理说明', ['项目','说明'], cleaning_rows)

# hyperlinks for single-URL cells
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for cell in row:
            if isinstance(cell.value, str) and cell.value.startswith('http') and '；' not in cell.value:
                cell.hyperlink = cell.value
                cell.style = 'Hyperlink'

wb.save(OUTPUT)
print(OUTPUT)
print('sheets:', '|'.join(wb.sheetnames))
print('rows:', {ws.title: ws.max_row for ws in wb.worksheets})
