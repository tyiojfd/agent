from copy import copy
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment
from openpyxl.utils import get_column_letter

INPUT = r'D:\python学习\baidupc\鲁迅故里景区资料整理_按大类重构.xlsx'
OUTPUT = r'D:\python学习\baidupc\鲁迅故里景区资料整理_按大类重构_链接可点击.xlsx'
TARGET_HEADERS = {'来源链接', '链接', 'URL'}
SEP = '；'

wb = load_workbook(INPUT)

for ws in wb.worksheets:
    if ws.max_row < 1:
        continue
    # Capture original target columns, process right-to-left so inserted columns don't shift unprocessed targets.
    targets = []
    for col in range(1, ws.max_column + 1):
        header = ws.cell(1, col).value
        if header in TARGET_HEADERS:
            targets.append(col)

    for col in sorted(targets, reverse=True):
        header = ws.cell(1, col).value
        values = []
        max_parts = 1
        for row in range(2, ws.max_row + 1):
            raw = ws.cell(row, col).value
            if isinstance(raw, str):
                parts = [p.strip() for p in raw.split(SEP) if p.strip()]
            elif raw:
                parts = [str(raw).strip()]
            else:
                parts = []
            values.append(parts)
            max_parts = max(max_parts, len(parts) if parts else 1)

        if max_parts > 1:
            # Rename the original link column and add one column per extra URL.
            ws.cell(1, col).value = f'{header}1'
            for i in range(2, max_parts + 1):
                ws.insert_cols(col + i - 1)
                ws.cell(1, col + i - 1).value = f'{header}{i}'
                # Copy visual style from the first link header/column.
                ws.cell(1, col + i - 1)._style = copy(ws.cell(1, col)._style)
                ws.cell(1, col + i - 1).font = copy(ws.cell(1, col).font)
                ws.cell(1, col + i - 1).fill = copy(ws.cell(1, col).fill)
                ws.cell(1, col + i - 1).border = copy(ws.cell(1, col).border)
                ws.cell(1, col + i - 1).alignment = copy(ws.cell(1, col).alignment)
                ws.column_dimensions[get_column_letter(col + i - 1)].width = 42

            for row_idx, parts in enumerate(values, start=2):
                for i in range(max_parts):
                    cell = ws.cell(row_idx, col + i)
                    # Copy style from the original URL cell where possible.
                    if i > 0:
                        cell._style = copy(ws.cell(row_idx, col)._style)
                        cell.alignment = Alignment(vertical='top', wrap_text=True)
                    value = parts[i] if i < len(parts) else ''
                    cell.value = value
                    if isinstance(value, str) and value.startswith('http'):
                        cell.hyperlink = value
                        cell.font = Font(color='0563C1', underline='single')
        else:
            # Single URL column: ensure every URL is a real Excel hyperlink.
            for row in range(2, ws.max_row + 1):
                cell = ws.cell(row, col)
                value = cell.value
                if isinstance(value, str) and value.startswith('http'):
                    cell.hyperlink = value
                    cell.font = Font(color='0563C1', underline='single')

    # Re-apply autofilter to the full used range after any inserted columns.
    if ws.max_row > 1 and ws.max_column > 1:
        ws.auto_filter.ref = ws.dimensions
        # Table column counts can become stale after inserting columns. Remove tables to avoid broken Excel table refs;
        # the cell styling and autofilter remain, and hyperlinks work normally.
        try:
            ws.tables.clear()
        except Exception:
            pass

wb.save(OUTPUT)
print(OUTPUT)
for ws in wb.worksheets:
    print(ws.title, ws.max_row, ws.max_column)
