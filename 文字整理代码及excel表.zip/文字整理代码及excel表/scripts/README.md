# 鲁迅故里景区资料整理 — 脚本说明

本目录存放生成 / 加工 `鲁迅故里景区资料整理_最终版.xlsx`（位于项目根目录）的全部 Python 脚本。
所有脚本内部的输入 / 输出路径都是**绝对路径**，指向项目根目录 `D:\python学习\baidupc\`，
因此脚本放在哪个文件夹都能正常运行；**只有 .py 被移动到了这里，.xlsx 产物仍留在根目录**。

## 目录结构（按流水线阶段编号，即执行顺序）

```
scripts/
├── 01_生成构建/        从原始资料生成基础 Excel 并定稿
├── 02_定稿修复/        针对最终版做就地修复 / 链接修正
├── 03_精简优化/        精简、增强、列宽 / 样式优化
├── 04_小红书增强/      小红书公开信息扩展、合并、分发到各表
├── 05_来源可信度/      来源可行度修正、可信度排序、标签去重
└── archive/           已废弃的旧版本
```

## 主流水线（生成「最终版」交付物）

| 顺序 | 脚本 | 输入 xlsx | 输出 xlsx | 作用 |
|----|------|-----------|-----------|------|
| 1 | `01_生成构建/generate_luxun_excel_v2.py` | （内置 sources 字典） | `鲁迅故里景区资料整理_按大类重构.xlsx` | 按大类重构生成基础表 |
| 2 | `01_生成构建/fix_excel_links.py` | `…_按大类重构.xlsx` | `…_按大类重构_链接可点击.xlsx` | 把来源链接列改成可点击 HYPERLINK |
| 3 | `01_生成构建/finalize_luxun_excel.py` | `…_按大类重构_链接可点击.xlsx` | **`鲁迅故里景区资料整理_最终版.xlsx`** | 重命名核心景点表、定稿 |
| 4 | `02_定稿修复/fix_05_remarks_split.py` | `…_最终版.xlsx`（就地） | `…_最终版.xlsx` | 05 备注栏拆分、咸亨酒店→咸亨酒店菜品、清理内部字眼 |
| 5 | `02_定稿修复/fix_sxlxmuseum_cert_links.py` | `…_最终版.xlsx` | `…_最终版_网址修正.xlsx` | 官方站链接统一为 http 以规避证书错误 |

## 小红书增强支线（从「最终版」分支，产出增强版）

| 顺序 | 脚本 | 输入 | 输出 | 作用 |
|----|------|------|------|------|
| 6 | `03_精简优化/refine_luxun_excel.py` | `…_最终版_网址修正.xlsx` | `…_精简增强版.xlsx` | 删除说明类表、精简增强 |
| 7 | `03_精简优化/optimize_luxun_excel.py` | `…_精简增强版.xlsx` | `…_最终优化版.xlsx` | 列宽 / 样式 / 排版优化 |
| 8 | `04_小红书增强/extend_xhs_luxun_guide_excel.py` | `D:\luxun\luxun_crawl_output\…csv`（爬虫产物） | 小红书扩展版 xlsx | 扩展小红书公开信息与攻略分类 |
| 9 | `04_小红书增强/merge_xhs_into_luxun_excel.py` | `…_最终优化版.xlsx` + 上面 8 的数据 | `…_最终优化版_合并小红书.xlsx` | 合并小红书数据，新增 07/08 表 |
| 10 | `04_小红书增强/distribute_xhs_into_six_sheets.py` | `…_合并小红书.xlsx` | `…_小红书汇总增强版.xlsx` | 按六个分类分发到各表 |
| 11 | `05_来源可信度/clean_feasibility_merge_excel.py` | `…_小红书汇总增强版.xlsx` | `…_来源可行度修正.xlsx` | 来源可行度修正 |
| 12 | `05_来源可信度/sort_source_credibility_excel.py` | `…_来源可行度修正.xlsx` | `…_来源可信度排序.xlsx` | 06 来源清单按可信度排序 |
| 13 | `05_来源可信度/dedupe_credibility_labels_excel.py` | `…_来源可信度排序.xlsx` | `…_来源可信度去重.xlsx` | 来源标签去重 |

## 归档

- `archive/generate_luxun_excel.py` —— 早期 v1 生成器，输出 `鲁迅故里景区资料整理.xlsx`；
  其产物未被下游任何脚本使用，已被 `generate_luxun_excel_v2.py` 取代，仅作留存。

## 运行方式

依赖 `openpyxl`（系统 Python 已安装）。任一脚本都可在其所在目录直接运行，例如：

```powershell
python "D:\python学习\baidupc\scripts\01_生成构建\generate_luxun_excel_v2.py"
```

> 注意：`merge_xhs_into_luxun_excel.py` 会读取并 exec `04_小红书增强/extend_xhs_luxun_guide_excel.py`
> 的源码以复用其整理好的数据，该路径已同步为新的绝对路径，移动后行为不变。
