import re
from pathlib import Path
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Side, Font, PatternFill
from openpyxl.utils import get_column_letter

INPUT = Path(r'D:\python学习\baidupc\鲁迅故里景区资料整理_小红书汇总增强版_来源可信度排序.xlsx')
OUTPUT = Path(r'D:\python学习\baidupc\鲁迅故里景区资料整理_小红书汇总增强版_来源可信度去重.xlsx')

wb = load_workbook(INPUT, data_only=False)
ws = wb['06_来源清单']
headers = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
desc_col = headers.index('可信度/使用说明') + 1

level_order = ['高', '中', '低']

def clean_label(text):
    text = str(text or '').strip()
    # Normalize old variants just in case.
    text = text.replace('可行度：', '')
    # Determine the first/strongest level appearing at the front or anywhere.
    level = None
    for lv in level_order:
        if re.search(rf'(^|[；;。\s]){lv}[。；;：:]', text) or text.startswith(lv):
            level = lv
            break
    if level is None:
        return text
    # Remove all standalone credibility labels anywhere in the text.
    # Examples removed: 高。 中。 低。 高； 中： 可行度：高。
    text = re.sub(r'(?:可行度：)?[高中低][。；;：:]\s*', '', text)
    text = re.sub(r'\s+', ' ', text).strip('；;。:： ')
    return f'{level}。{text}' if text else f'{level}。'

changed = 0
for r in range(2, ws.max_row + 1):
    cell = ws.cell(r, desc_col)
    old = cell.value or ''
    new = clean_label(old)
    if new != old:
        changed += 1
        cell.value = new

# Keep formatting consistent.
header_fill = PatternFill('solid', fgColor='1F4E78')
header_font = Font(color='FFFFFF', bold=True)
thin = Side(style='thin', color='D9E2F3')
LONG_HEADERS = {'内容', '景区简介', '历史简介', '主要看点', '与鲁迅/作品关系', '游览提示', '活动内容', '文化意义', '生平事件', '与景区/展陈关系', '建议', '可信度/使用说明'}
for sheet in wb.worksheets:
    sheet.sheet_view.showGridLines = False
    sheet.freeze_panes = 'A2'
    if sheet.max_row > 1 and sheet.max_column > 1:
        sheet.auto_filter.ref = sheet.dimensions
    for cell in sheet[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = Border(top=thin, left=thin, right=thin, bottom=thin)
    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            header = sheet.cell(1, cell.column).value
            value = '' if cell.value is None else str(cell.value)
            if value.startswith('=HYPERLINK('):
                cell.font = Font(color='0563C1', underline='single')
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            elif header in LONG_HEADERS:
                cell.alignment = Alignment(horizontal='left', vertical='top', wrap_text=True)
            elif len(value) <= 28:
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            else:
                cell.alignment = Alignment(horizontal='left', vertical='top', wrap_text=True)
            cell.border = Border(top=thin, left=thin, right=thin, bottom=thin)
    for c in range(1, sheet.max_column + 1):
        header = sheet.cell(1, c).value
        letter = get_column_letter(c)
        if header in ('景区简介', '历史简介', '生平事件', '内容', '整理内容'):
            sheet.column_dimensions[letter].width = 72
        elif header == '可信度/使用说明':
            sheet.column_dimensions[letter].width = 52
        elif header == '备注':
            sheet.column_dimensions[letter].width = 46
        elif isinstance(header, str) and (header.startswith('来源链接') or header in ('URL', '链接')):
            sheet.column_dimensions[letter].width = 16
        elif header in ('景点名称', '类别', '阶段', '活动名称', '项目', '主题'):
            sheet.column_dimensions[letter].width = 22
        else:
            sheet.column_dimensions[letter].width = min(max(sheet.column_dimensions[letter].width or 24, 20), 55)

wb.save(OUTPUT)
print(OUTPUT)
print('changed', changed)
