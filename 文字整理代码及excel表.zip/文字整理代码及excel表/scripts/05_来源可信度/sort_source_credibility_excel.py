from pathlib import Path
from copy import copy
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Side, Font, PatternFill
from openpyxl.utils import get_column_letter

INPUT = Path(r'D:\python学习\baidupc\鲁迅故里景区资料整理_小红书汇总增强版_来源可行度修正.xlsx')
OUTPUT = Path(r'D:\python学习\baidupc\鲁迅故里景区资料整理_小红书汇总增强版_来源可信度排序.xlsx')

wb = load_workbook(INPUT, data_only=False)
ws = wb['06_来源清单']

headers = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
hm = {h: i + 1 for i, h in enumerate(headers)}
desc_col = hm['可信度/使用说明']
idx_col = hm.get('序号', 1)

# Keep styles from the first data row for re-application after sorting.
row_style = []
if ws.max_row >= 2:
    for c in range(1, ws.max_column + 1):
        row_style.append(copy(ws.cell(2, c)._style))

rank = {'高': 1, '中': 2, '低': 3}

def extract_level(text):
    text = str(text or '').strip()
    # Current format before cleanup: 可行度：高。...
    for level in ['高', '中', '低']:
        if text.startswith(f'可行度：{level}') or text.startswith(level):
            return level
    # Fallback keyword judgment for rows that may not have a prefix.
    if '小红书站内搜索入口' in text or '需App' in text or '登录查看' in text:
        return '低'
    if '官方' in text or '政府' in text or '主流媒体' in text or '文旅' in text:
        return '高'
    return '中'

def clean_desc(text):
    text = str(text or '')
    text = text.replace('可行度：', '')
    # Normalize punctuation after the leading rating.
    for level in ['高', '中', '低']:
        if text.startswith(level) and len(text) > 1 and text[1] not in '。；：:':
            text = level + '。' + text[1:]
    return text

# Read, clean, sort rows.
rows = []
for r in range(2, ws.max_row + 1):
    values = [ws.cell(r, c).value for c in range(1, ws.max_column + 1)]
    original_desc = values[desc_col - 1]
    level = extract_level(original_desc)
    values[desc_col - 1] = clean_desc(original_desc)
    rows.append((rank.get(level, 99), level, values))

rows.sort(key=lambda x: (x[0], str(x[2][hm.get('来源类型', 3) - 1] or ''), str(x[2][hm.get('来源名称', 2) - 1] or '')))

# Clear data rows.
for r in range(2, ws.max_row + 1):
    for c in range(1, ws.max_column + 1):
        ws.cell(r, c).value = None

# Rewrite rows and renumber 序号.
for out_r, (_, _, values) in enumerate(rows, start=2):
    if idx_col:
        values[idx_col - 1] = out_r - 1
    for c, value in enumerate(values, start=1):
        cell = ws.cell(out_r, c)
        cell.value = value
        if row_style:
            cell._style = copy(row_style[c - 1])

# Re-style the workbook enough to keep visual consistency.
header_fill = PatternFill('solid', fgColor='1F4E78')
header_font = Font(color='FFFFFF', bold=True)
thin = Side(style='thin', color='D9E2F3')
LONG_HEADERS = {'内容', '景区简介', '历史简介', '主要看点', '与鲁迅/作品关系', '游览提示', '活动内容', '文化意义', '生平事件', '与景区/展陈关系', '建议', '可信度/使用说明'}
for sheet in wb.worksheets:
    sheet.sheet_view.showGridLines = False
    sheet.freeze_panes = 'A2'
    if sheet.max_row > 1 and sheet.max_column > 1:
        sheet.auto_filter.ref = sheet.dimensions
    for cell in sheet[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = Border(top=thin, left=thin, right=thin, bottom=thin)
    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            header = sheet.cell(1, cell.column).value
            value = '' if cell.value is None else str(cell.value)
            if value.startswith('=HYPERLINK('):
                cell.font = Font(color='0563C1', underline='single')
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            elif header in LONG_HEADERS:
                cell.alignment = Alignment(horizontal='left', vertical='top', wrap_text=True)
            elif len(value) <= 28:
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            else:
                cell.alignment = Alignment(horizontal='left', vertical='top', wrap_text=True)
            cell.border = Border(top=thin, left=thin, right=thin, bottom=thin)
    for c in range(1, sheet.max_column + 1):
        header = sheet.cell(1, c).value
        letter = get_column_letter(c)
        if header in ('景区简介', '历史简介', '生平事件', '内容', '整理内容'):
            sheet.column_dimensions[letter].width = 72
        elif header == '可信度/使用说明':
            sheet.column_dimensions[letter].width = 52
        elif header == '备注':
            sheet.column_dimensions[letter].width = 46
        elif isinstance(header, str) and (header.startswith('来源链接') or header in ('URL', '链接')):
            sheet.column_dimensions[letter].width = 16
        elif header in ('景点名称', '类别', '阶段', '活动名称', '项目', '主题'):
            sheet.column_dimensions[letter].width = 22
        else:
            sheet.column_dimensions[letter].width = min(max(sheet.column_dimensions[letter].width or 24, 20), 55)

wb.save(OUTPUT)
print(OUTPUT)
print('rows', len(rows))
print('levels', {level: sum(1 for _, l, _ in rows if l == level) for level in ['高', '中', '低']})
