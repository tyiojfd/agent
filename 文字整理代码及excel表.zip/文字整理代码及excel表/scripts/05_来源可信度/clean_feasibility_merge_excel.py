from pathlib import Path
from copy import copy
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Side, Font, PatternFill
from openpyxl.utils import get_column_letter

INPUT = Path(r'D:\python学习\baidupc\鲁迅故里景区资料整理_小红书汇总增强版.xlsx')
OUTPUT = Path(r'D:\python学习\baidupc\鲁迅故里景区资料整理_小红书汇总增强版_来源可行度修正.xlsx')

wb = load_workbook(INPUT, data_only=False)

header_fill = PatternFill('solid', fgColor='1F4E78')
header_font = Font(color='FFFFFF', bold=True)
thin = Side(style='thin', color='D9E2F3')
LONG_HEADERS = {'内容', '景区简介', '历史简介', '主要看点', '与鲁迅/作品关系', '游览提示', '活动内容', '文化意义', '生平事件', '与景区/展陈关系', '建议', '可信度/使用说明'}


def header_map(ws):
    return {ws.cell(1, c).value: c for c in range(1, ws.max_column + 1)}


def unmerge_and_fill(ws):
    for rng in list(ws.merged_cells.ranges):
        val = ws.cell(rng.min_row, rng.min_col).value
        ws.unmerge_cells(str(rng))
        for r in range(rng.min_row, rng.max_row + 1):
            for c in range(rng.min_col, rng.max_col + 1):
                ws.cell(r, c).value = val


def merge_same_values(ws, header_name):
    hm = header_map(ws)
    col = hm.get(header_name)
    if not col or ws.max_row < 2:
        return
    start = 2
    current = ws.cell(start, col).value
    for r in range(3, ws.max_row + 2):
        value = ws.cell(r, col).value if r <= ws.max_row else None
        if value != current:
            end = r - 1
            if current not in (None, '') and end > start:
                ws.merge_cells(start_row=start, start_column=col, end_row=end, end_column=col)
                ws.cell(start, col).alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            elif current not in (None, ''):
                ws.cell(start, col).alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            start = r
            current = value


def merge_note_column(ws):
    hm = header_map(ws)
    col = hm.get('备注')
    if not col or ws.max_row < 2:
        return
    notes = []
    label_col = 2 if ws.max_column >= 2 else 1
    for r in range(2, ws.max_row + 1):
        note = ws.cell(r, col).value
        if note not in (None, ''):
            label = ws.cell(r, label_col).value or ws.cell(r, 1).value or f'第{r}行'
            line = f'{label}：{note}'
            if line not in notes:
                notes.append(line)
    for r in range(2, ws.max_row + 1):
        ws.cell(r, col).value = None
    ws.cell(2, col).value = '\n'.join(notes) if notes else '无特别备注；动态信息以官方公告、实时地图、住宿/餐饮平台和小红书站内最新笔记为准。'
    ws.merge_cells(start_row=2, start_column=col, end_row=ws.max_row, end_column=col)
    ws.cell(2, col).alignment = Alignment(vertical='top', wrap_text=True)


def decide_feasibility(source_type, url, note):
    text = f'{source_type} {url} {note}'
    # 可直接执行/核验的官方、政府、地图、酒店/住宿平台、主流新闻来源，可行度高。
    high_keys = ['官方', '政府', '文旅厅', '中国邮政', '绍兴网', '中新网', '新华网', '央视网', '地图', '高德', 'amap', '携程', 'ctrip', 'Trip.com', 'Klook', '华住', '酒店官方']
    # 攻略、转载、搜索摘要适合作参考，但需现场/实时核对，可行度中。
    medium_keys = ['本地宝', '攻略', '美食攻略', '搜狐', '搜索结果', '住宿平台', '旅游平台', '出版传媒商报', '中国青年报', '论文']
    # 小红书搜索入口只提供检索方向，不保证笔记可直接打开或内容稳定，可行度低。
    low_keys = ['小红书站内搜索入口', 'xiaohongshu.com/search_result', '站内检索', '需App', '登录查看']
    if any(k in text for k in low_keys):
        return '低'
    if any(k in text for k in high_keys):
        return '高'
    if any(k in text for k in medium_keys):
        return '中'
    return '中'

# 1) 清理 06 来源清单 “可信度/使用说明”列，并加入可行度评定。
if '06_来源清单' in wb.sheetnames:
    ws = wb['06_来源清单']
    unmerge_and_fill(ws)
    hm = header_map(ws)
    desc_col = hm.get('可信度/使用说明')
    type_col = hm.get('来源类型')
    url_col = hm.get('URL')
    if desc_col:
        for r in range(2, ws.max_row + 1):
            desc = ws.cell(r, desc_col).value or ''
            source_type = ws.cell(r, type_col).value if type_col else ''
            url = ws.cell(r, url_col).value if url_col else ''
            # 删除用户指定字样及相邻标点。
            desc = str(desc).replace('来自07小红书数据汇总的补充来源；', '')
            desc = desc.replace('来自07小红书数据汇总的补充来源。', '')
            desc = desc.replace('来自07小红书数据汇总的补充来源', '')
            desc = desc.strip('；。 ')
            feasibility = decide_feasibility(source_type, url, desc)
            # 避免重复追加。
            if '可行度：' in desc:
                # 如果已有旧评定，先移除再写入新评定。
                parts = [p for p in desc.split('；') if not p.startswith('可行度：')]
                desc = '；'.join(parts).strip('；。 ')
            ws.cell(r, desc_col).value = f'可行度：{feasibility}。{desc}' if desc else f'可行度：{feasibility}。'

# 2) 05 实用信息：按类别排序，让相同类别连续，然后合并“类别”列。
if '05_实用信息' in wb.sheetnames:
    ws = wb['05_实用信息']
    unmerge_and_fill(ws)
    hm = header_map(ws)
    headers = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
    cat_col = hm.get('类别')
    if cat_col:
        rows = []
        for r in range(2, ws.max_row + 1):
            row_values = [ws.cell(r, c).value for c in range(1, ws.max_column + 1)]
            rows.append(row_values)
        order = {
            '开放预约': 1,
            '咨询': 2,
            '交通': 3,
            '住宿': 4,
            '美食': 5,
            '游览路线': 6,
            '游览时间/避峰': 7,
            '拍照打卡': 8,
            '文创/商铺': 9,
            '小红书检索词': 10,
            '文明安全': 11,
        }
        def key(row):
            cat = row[cat_col - 1] or ''
            return (order.get(cat, 99), str(cat), str(row[1] or ''))
        rows.sort(key=key)
        # 清空原数据区并重写。
        for r in range(2, ws.max_row + 1):
            for c in range(1, ws.max_column + 1):
                ws.cell(r, c).value = None
        for r_idx, row_values in enumerate(rows, start=2):
            for c_idx, value in enumerate(row_values, start=1):
                ws.cell(r_idx, c_idx).value = value
        merge_same_values(ws, '类别')
        merge_note_column(ws)

# 3) 保持 01 景区总览大类合并、其他备注合并；如果已经合并，先填充/再合并避免格式错乱。
for ws in wb.worksheets:
    if ws.title != '05_实用信息':
        # 不打散 05 刚做好的类别合并；备注如已有合并则保留。
        pass
if '01_景区总览' in wb.sheetnames:
    ws = wb['01_景区总览']
    unmerge_and_fill(ws)
    merge_same_values(ws, '大类')
    merge_note_column(ws)

# 对其他表的备注列做一次规范合并（先解合并填充值再合并）。
for s in ['02_鲁迅故里核心景点介绍', '03_活动', '04_鲁迅生平']:
    if s in wb.sheetnames:
        ws = wb[s]
        unmerge_and_fill(ws)
        merge_note_column(ws)

# 4) 全局样式与短文本居中。
for ws in wb.worksheets:
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = 'A2'
    if ws.max_row > 1 and ws.max_column > 1:
        ws.auto_filter.ref = ws.dimensions
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = Border(top=thin, left=thin, right=thin, bottom=thin)
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            header = ws.cell(1, cell.column).value
            value = '' if cell.value is None else str(cell.value)
            if value.startswith('=HYPERLINK('):
                cell.font = Font(color='0563C1', underline='single')
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            elif header in LONG_HEADERS:
                cell.alignment = Alignment(horizontal='left', vertical='top', wrap_text=True)
            elif len(value) <= 28:
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            else:
                cell.alignment = Alignment(horizontal='left', vertical='top', wrap_text=True)
            cell.border = Border(top=thin, left=thin, right=thin, bottom=thin)
    hm = header_map(ws)
    for header in ['大类', '类别']:
        if header in hm:
            for rng in ws.merged_cells.ranges:
                if rng.min_col == hm[header] and rng.max_col == hm[header]:
                    ws.cell(rng.min_row, rng.min_col).alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    for c in range(1, ws.max_column + 1):
        header = ws.cell(1, c).value
        letter = get_column_letter(c)
        if header in ('景区简介', '历史简介', '生平事件', '内容', '整理内容'):
            ws.column_dimensions[letter].width = 72
        elif header in ('备注', '可信度/使用说明'):
            ws.column_dimensions[letter].width = 52 if header == '可信度/使用说明' else 46
        elif isinstance(header, str) and (header.startswith('来源链接') or header in ('URL', '链接')):
            ws.column_dimensions[letter].width = 16
        elif header in ('景点名称', '类别', '阶段', '活动名称', '项目', '主题'):
            ws.column_dimensions[letter].width = 22
        else:
            ws.column_dimensions[letter].width = min(max(ws.column_dimensions[letter].width or 24, 20), 55)

wb.save(OUTPUT)
print(OUTPUT)
print('|'.join(wb.sheetnames))
if '05_实用信息' in wb.sheetnames:
    print('05 merges:', [str(r) for r in wb['05_实用信息'].merged_cells.ranges])
if '06_来源清单' in wb.sheetnames:
    print('06 rows:', wb['06_来源清单'].max_row)
