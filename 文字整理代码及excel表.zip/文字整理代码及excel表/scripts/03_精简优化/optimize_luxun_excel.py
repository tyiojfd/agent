from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Side, PatternFill, Font
from openpyxl.utils import get_column_letter

INPUT = r'D:\python学习\baidupc\鲁迅故里景区资料整理_精简增强版.xlsx'
OUTPUT = r'D:\python学习\baidupc\鲁迅故里景区资料整理_最终优化版.xlsx'

wb = load_workbook(INPUT)

def header_map(ws):
    return {ws.cell(1, c).value: c for c in range(1, ws.max_column + 1)}

def set_by_name(ws, name_col, name, field, value):
    hm = header_map(ws)
    if field not in hm:
        return False
    for r in range(2, ws.max_row + 1):
        if ws.cell(r, name_col).value == name:
            cell = ws.cell(r, hm[field])
            cell.value = value
            cell.alignment = Alignment(horizontal='left', vertical='top', wrap_text=True)
            return True
    return False

# 1) 增强 02_鲁迅故里核心景点介绍 的“历史简介”。
spot_sheet = '02_鲁迅故里核心景点介绍'
if spot_sheet in wb.sheetnames:
    ws = wb[spot_sheet]
    hm = header_map(ws)
    name_col = hm.get('景点名称', 1)
    histories = {
        '鲁迅故里景区': '鲁迅故里所在街区是鲁迅出生、成长和早年求学活动最集中的区域，原本由周家新台门、周家老台门、寿家台门、朱家台门以及周边水乡街巷共同构成。20世纪以来，随着鲁迅故居、三味书屋等遗迹被保护和开放，绍兴逐步形成以鲁迅纪念、故居保护、作品阐释和街区风貌恢复为核心的文化景区。绍兴鲁迅纪念馆始建于1953年，之后鲁迅故里保护工程和街区整治进一步强化了传统台门、水乡街巷和鲁迅文化展示的整体性，使这里从单个故居纪念点发展为综合性的历史文化街区。',
        '鲁迅故居': '鲁迅故居即周家新台门的一部分。周家新台门建于清嘉庆年间，是覆盆桥周氏家族三个台门中建成较晚的一座大型台门建筑。1881年9月25日，鲁迅出生在这里，并在此度过童年和少年时期，直到18岁离开绍兴去南京求学。周家新台门原居住着周氏多个房族，建筑规模较大，坐北朝南、青瓦粉墙、砖木结构，共分六进，大小房屋80余间，连同后面的百草园占地4000余平方米。这里见证了鲁迅家族生活、家道变化和少年鲁迅成长经历，是理解鲁迅早年生活环境的核心遗迹。',
        '百草园': '百草园原本并非专门园林，而是周家新台门后面的普通菜园，为新台门周氏族人共有，占地近2000平方米。园中平时种植瓜菜，秋后用于晒稻谷。少年鲁迅常在这里玩耍，观察草木虫鸟，听传说、找乐趣。多年后，鲁迅在《从百草园到三味书屋》中回忆这一空间，把普通菜园写成充满童年想象和自然趣味的“乐园”。百草园后来因文学作品而成为著名文化景点，文中提到的泥墙根、石井等意象也成为现场讲解和课文研学的重要内容。',
        '三味书屋': '三味书屋位于寿家台门东侧厢房。寿家台门建于清嘉庆年间，前临小河，与周家老台门隔河相望。三味书屋是当时绍兴城内颇有名气的私塾，鲁迅约12岁至17岁在这里读书。书屋约35平方米，正中悬挂清代书法家梁同书所题“三味书屋”匾额，匾下挂《松鹿图》，两侧有对联，内部保留塾师讲台和学生座位等传统私塾格局。鲁迅在这里学习经史、诗文和古典文学，也阅读课外书。它既是鲁迅传统教育经历的见证，也是《从百草园到三味书屋》中由童年游戏转入私塾读书的重要现实场景。',
        '鲁迅祖居': '鲁迅祖居又称周家老台门，是周氏祖先居住和家族礼制生活的重要建筑空间。周家老台门与周家新台门、寿家台门隔河相望或相邻，共同构成鲁迅故里区域的传统台门建筑格局。祖居体现了绍兴传统大家族的居住方式、宗族关系和礼仪空间，与鲁迅故居所呈现的个人成长环境互为补充。通过祖居可以看到鲁迅家族的根脉、绍兴台门建筑的历史层次，以及晚清绍兴士绅家庭生活的空间组织。',
        '绍兴鲁迅纪念馆': '绍兴鲁迅纪念馆始建于1953年，是新中国成立后浙江省较早建立的纪念性人物博物馆之一。2003年前后，为恢复鲁迅故里的传统风貌，原有与街区环境尺度不协调的陈列厅被拆除，新建纪念馆位于鲁迅故里东侧，东接鲁迅祖居，西邻周家新台门，北毗朱家台门，南临东昌坊口。纪念馆总占地面积约6000平方米，总建筑面积约5000平方米，采用“老房子、新空间”的理念，外部延续绍兴台门建筑形式，内部以鲁迅生平事迹陈列为主线，系统呈现鲁迅一生业绩及其与故乡绍兴的渊源。',
        '鲁迅笔下风情园': '鲁迅笔下风情园依托朱家台门修缮而成。朱家台门位于百草园旁，是绍兴古城保存较完整的典型花园式台门之一。资料称朱家台门原为越王望花宫故址，后与明初名将胡大海官宅遗存等地方历史传说相联系。台门内有百年罗汉松、盘槐、红梅、绿萼梅等花木，并有约400平方米水池。清宣统元年，绍兴名士程柏堂曾题写与越王望花宫故址相关的文字并勒石于池畔。修缮后辟为“鲁迅笔下风情园”，用于展示鲁迅作品中绍兴地方风物和传统台门园林生活。',
        '鲁迅故里步行街/风情街': '鲁迅故里步行街/风情街是在鲁迅故里历史街区保护、景区开放和绍兴古城旅游发展过程中逐步形成的游览服务空间。它依托鲁迅中路及周边传统街巷，将鲁迅故居、三味书屋、百草园、祖居、纪念馆等文化遗迹与绍兴小吃、黄酒体验、文创商铺、咸亨酒店等旅游服务联系起来。其历史基础是绍兴古城原有街巷和水乡生活空间，现代表现则是文化旅游街区。整理资料时需区分文物遗迹的历史事实与当代商业街区的经营内容。',
        '沈园': '沈园又名沈氏园，原为沈氏私家花园，至今已有800多年历史，是绍兴历代古典园林中保存至今的宋代名园之一。沈园因南宋诗人陆游与唐琬的爱情故事以及《钗头凤》词而闻名。相传陆游与唐琬被迫分离后在沈园重逢，陆游伤感题词，使沈园成为承载宋代园林、爱情文学和绍兴人文记忆的重要景点。现今沈园与鲁迅故里同属“鲁迅故里·沈园景区”游览体系，但主题侧重不同：鲁迅故里突出鲁迅成长与现代文学记忆，沈园则突出宋代园林、陆游唐琬故事和《钗头凤》文化。',
    }
    for name, history in histories.items():
        set_by_name(ws, name_col, name, '历史简介', history)

# 2) 05_实用信息：类别相同的连续单元格合并并居中。
info_sheet = '05_实用信息'
if info_sheet in wb.sheetnames:
    ws = wb[info_sheet]
    hm = header_map(ws)
    cat_col = hm.get('类别')
    if cat_col and ws.max_row >= 2:
        # 先解除该列可能已有的合并（一般没有），避免重复运行报错。
        for rng in list(ws.merged_cells.ranges):
            if rng.min_col == cat_col and rng.max_col == cat_col:
                ws.unmerge_cells(str(rng))
        start = 2
        current = ws.cell(start, cat_col).value
        for r in range(3, ws.max_row + 2):
            value = ws.cell(r, cat_col).value if r <= ws.max_row else None
            if value != current:
                end = r - 1
                if current not in (None, '') and end > start:
                    ws.merge_cells(start_row=start, start_column=cat_col, end_row=end, end_column=cat_col)
                    cell = ws.cell(start, cat_col)
                    cell.value = current
                    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
                elif current not in (None, ''):
                    ws.cell(start, cat_col).alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
                start = r
                current = value

# 3) 字少的单元格文字居中处理。长文本字段保持靠左顶端，链接公式和来源名称适当居中。
LONG_HEADERS = {'内容', '景区简介', '历史简介', '主要看点', '与鲁迅/作品关系', '游览提示', '活动内容', '文化意义', '生平事件', '与景区/展陈关系', '建议', '可信度/使用说明'}
SHORT_LEN = 28
thin = Side(style='thin', color='D9E2F3')
header_fill = PatternFill('solid', fgColor='1F4E78')
header_font = Font(color='FFFFFF', bold=True)
for ws in wb.worksheets:
    hm = header_map(ws)
    # header style
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = Border(top=thin, left=thin, right=thin, bottom=thin)
    # cell style
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            header = ws.cell(1, cell.column).value
            value = cell.value
            text = '' if value is None else str(value)
            # Preserve link formula display centered.
            if text.startswith('=HYPERLINK('):
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
                cell.font = Font(color='0563C1', underline='single')
            elif header in LONG_HEADERS:
                cell.alignment = Alignment(horizontal='left', vertical='top', wrap_text=True)
            elif len(text) <= SHORT_LEN:
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            else:
                cell.alignment = Alignment(horizontal='left', vertical='top', wrap_text=True)
            cell.border = Border(top=thin, left=thin, right=thin, bottom=thin)
    # For merged cells that should be centered.
    if ws.title == '01_景区总览' and '大类' in hm:
        ws.cell(2, hm['大类']).alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    if ws.title == info_sheet and '类别' in hm:
        for rng in ws.merged_cells.ranges:
            if rng.min_col == hm['类别'] and rng.max_col == hm['类别']:
                ws.cell(rng.min_row, rng.min_col).alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    # sizes
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = 'A2'
    if ws.max_row > 1 and ws.max_column > 1:
        ws.auto_filter.ref = ws.dimensions
    for c in range(1, ws.max_column + 1):
        header = ws.cell(1, c).value
        letter = get_column_letter(c)
        if header in ('景区简介', '历史简介', '生平事件'):
            ws.column_dimensions[letter].width = 75
        elif header in ('备注',):
            ws.column_dimensions[letter].width = 42
        elif isinstance(header, str) and (header.startswith('来源链接') or header in ('URL', '链接')):
            ws.column_dimensions[letter].width = 16
        elif header in ('景点名称', '类别', '阶段', '活动名称'):
            ws.column_dimensions[letter].width = 20
        elif c <= 2:
            ws.column_dimensions[letter].width = max(ws.column_dimensions[letter].width or 18, 18)
        else:
            ws.column_dimensions[letter].width = min(max(ws.column_dimensions[letter].width or 24, 22), 55)

wb.save(OUTPUT)
print(OUTPUT)
print('|'.join(wb.sheetnames))
