from openpyxl import load_workbook
from openpyxl.styles import Alignment, PatternFill, Font, Border, Side
from openpyxl.utils import get_column_letter

INPUT = r'D:\python学习\baidupc\鲁迅故里景区资料整理_最终版_网址修正.xlsx'
OUTPUT = r'D:\python学习\baidupc\鲁迅故里景区资料整理_精简增强版.xlsx'

wb = load_workbook(INPUT)

# 1. 删除用户指定的说明类工作表。
for sheet_name in ['00_使用说明', '08_抓取清理说明']:
    if sheet_name in wb.sheetnames:
        del wb[sheet_name]

# 如果来源清单仍为 07，顺手调整为连续编号，便于最终文件浏览。
if '07_来源清单' in wb.sheetnames and '06_来源清单' not in wb.sheetnames:
    wb['07_来源清单'].title = '06_来源清单'

# 工具函数。
def header_map(ws):
    return {ws.cell(1, c).value: c for c in range(1, ws.max_column + 1)}

def set_by_name(ws, name_col, name, field, value):
    hm = header_map(ws)
    if field not in hm:
        return
    for r in range(2, ws.max_row + 1):
        if ws.cell(r, name_col).value == name:
            cell = ws.cell(r, hm[field])
            cell.value = value
            cell.alignment = Alignment(vertical='top', wrap_text=True)
            return

# 2. 增强“02_鲁迅故里核心景点介绍”的“景区简介”。
spot_sheet = '02_鲁迅故里核心景点介绍'
if spot_sheet in wb.sheetnames:
    ws = wb[spot_sheet]
    hm = header_map(ws)
    name_col = hm.get('景点名称', 1)
    intros = {
        '鲁迅故里景区': '鲁迅故里景区位于绍兴古城鲁迅中路一带，是以鲁迅出生、成长、求学和作品记忆为核心组织起来的历史文化街区。景区保留并展示鲁迅故居、鲁迅祖居、三味书屋、百草园、绍兴鲁迅纪念馆、鲁迅笔下风情园等一组人文古迹，把传统台门建筑、江南水乡街巷、鲁迅家族生活空间和文学作品场景连成完整游线。它既是了解鲁迅早年生活与故乡关系的实景课堂，也是绍兴古城文化、红色旅游和中小学生研学的重要承载地。',
        '鲁迅故居': '鲁迅故居即周家新台门的一部分，是鲁迅出生并度过童年、少年时期的主要生活场所。周家新台门坐北朝南，青瓦粉墙、砖木结构，具有绍兴传统台门建筑特征。故居内部通过厅堂、卧室、家族生活空间等展示，呈现鲁迅少年时代的家庭环境、绍兴大族居住格局和晚清江南士绅家庭生活面貌。故居与后面的百草园相连，适合与鲁迅童年记忆和《从百草园到三味书屋》一起理解。',
        '百草园': '百草园位于鲁迅故居后面，原本是新台门周氏族人共有的普通菜园，平时种瓜菜、秋后晒稻谷。因为鲁迅在散文《从百草园到三味书屋》中深情回忆这里的草木、昆虫、泥墙根、石井和童年游戏，它从普通园地变成中国现代文学中极具辨识度的童年空间。今天的百草园保留了泥墙根、石井等关键意象，是把课本文字转化为现场体验的核心地点。',
        '三味书屋': '三味书屋位于寿家台门东侧厢房，是鲁迅少年时期读书的私塾，也是《从百草园到三味书屋》中最重要的求学场景。书屋空间不大，约35平方米，室内悬挂“三味书屋”匾额，匾下有《松鹿图》，保留塾师讲台、学生座位和传统私塾陈设。它集中呈现晚清绍兴私塾教育环境，也连接了鲁迅从童年游戏世界进入正规读书生活的转折。',
        '鲁迅祖居': '鲁迅祖居又称周家老台门，是周氏家族祖先居住和家族礼制生活的重要空间。祖居与周家新台门、寿家台门等共同构成鲁迅故里传统台门建筑群，能够帮助游客理解鲁迅家族的世系背景、绍兴传统大家族居住方式和地方社会生活。相比鲁迅故居更偏向个人成长空间，祖居更强调家族根脉、传统礼俗和台门建筑整体格局。',
        '绍兴鲁迅纪念馆': '绍兴鲁迅纪念馆是系统展示鲁迅生平、思想、文学成就及其与故乡绍兴关系的纪念性人物博物馆。纪念馆位于鲁迅故里东侧，建筑外观延续绍兴台门风貌，以“老房子、新空间”的思路融入历史街区。馆内陈列通常以鲁迅生平事迹为主线，结合文献、图片、实物和场景资料，帮助游客从故居实景进一步进入鲁迅一生经历、精神品格和现代文学贡献的理解。',
        '鲁迅笔下风情园': '鲁迅笔下风情园依托朱家台门修缮而成，位于百草园旁，是展示绍兴台门园林、水乡生活和鲁迅作品中地方风物的重要空间。园内有花木、水池和传统台门格局，兼具古城宅院、园林和民俗展示特征。它不是单一故居房间，而是以“鲁迅笔下绍兴风情”为线索，把绍兴地方生活、园林景观和作品意象结合起来，适合作为核心故居游览后的补充体验。',
        '鲁迅故里步行街/风情街': '鲁迅故里步行街/风情街是围绕鲁迅故里核心景点形成的历史街区游览和服务空间，沿鲁迅中路及周边街巷展开。这里把鲁迅文化、绍兴水乡街巷、地方小吃、黄酒体验、文创商铺和咸亨酒店等旅游服务连接起来，方便游客在参观故居、百草园、三味书屋之后继续体验绍兴古城生活气息。需要注意的是，街区商业内容会随经营变化而变化，应与文物古迹信息区分。',
        '沈园': '沈园又名沈氏园，位于鲁迅中路318号，地处鲁迅故里东侧，是鲁迅故里·沈园景区体系中的重要联游景点。沈园原为沈氏私家花园，是绍兴著名宋式园林，以小桥流水、亭台楼阁、园林院落和陆游、唐琬爱情故事闻名。与鲁迅故里侧重鲁迅童年、家族和文学记忆不同，沈园突出宋代园林、爱情词章和绍兴古城人文气质，适合与鲁迅故里安排在同一半日或一日游线中。',
    }
    for name, intro in intros.items():
        set_by_name(ws, name_col, name, '景区简介', intro)

# 3. 增强“04_鲁迅生平”的“生平事件”。
life_sheet = '04_鲁迅生平'
if life_sheet in wb.sheetnames:
    ws = wb[life_sheet]
    hm = header_map(ws)
    stage_col = hm.get('阶段', 1)
    events = {
        '出生与童年': '1881年9月25日，鲁迅出生于浙江绍兴周家新台门，本名周树人。周家新台门所在的绍兴传统台门、水乡街巷和家族生活，是鲁迅最早接触世界的环境。童年时期的家庭、街区、自然园地和民间传说，后来不断进入他的回忆性散文和小说创作，成为理解鲁迅“故乡经验”的起点。',
        '绍兴生活': '鲁迅在绍兴生活到18岁左右，经历了从家族相对殷实到家道中落的变化，也接触到绍兴地方社会、传统礼教、民俗信仰和普通民众生活。这一阶段形成的故乡记忆，不仅体现在《从百草园到三味书屋》，也与《故乡》《祝福》《社戏》《孔乙己》等作品中的绍兴风物、人物关系和社会观察密切相关。',
        '童年游玩': '少年鲁迅常在百草园玩耍，观察草木虫鸟，在泥墙根、石井边寻找童年乐趣。多年以后，他在《从百草园到三味书屋》中把这个普通菜园写成充满声音、色彩、传说和游戏的“乐园”。百草园因此不仅是地理空间，也是鲁迅文学中童年自由、自然趣味和记忆书写的象征。',
        '私塾求学': '鲁迅约12岁至17岁在三味书屋读书，接受传统私塾教育，学习《四书》《五经》、唐诗以及古典文学作品，也阅读了不少课外书。三味书屋的规矩、塾师、课桌、匾额和后园活动，后来都被写入《从百草园到三味书屋》。这一阶段体现鲁迅从童年游戏进入传统教育体系的经历，也为其后来的文学修养打下基础。',
        '离乡求学': '18岁后，鲁迅离开绍兴前往南京求学，开始接触近代新式教育和更广阔的社会现实。离开故乡并不意味着绍兴经验的结束，相反，故乡记忆成为他日后审视传统社会、家族伦理、乡土人情和国民精神的重要参照。鲁迅故里游览中，“从绍兴出发”是理解其人生道路的重要节点。',
        '鲁迅与绍兴': '绍兴是鲁迅的出生地和精神记忆的重要来源。鲁迅作品中反复出现的水乡、台门、私塾、社戏、祝福、酒店、乡邻和旧礼教，都与绍兴生活经验存在密切联系。鲁迅故里景区通过故居、祖居、百草园、三味书屋、风情园和纪念馆，把这些分散在作品中的故乡元素重新组织为可参观、可讲解、可研学的实景体系。',
        '逝世': '1936年10月19日，鲁迅在上海病逝。鲁迅一生经历了从绍兴童年、南京求学、日本留学到北京、厦门、广州、上海等地工作与写作的过程，最终成为中国现代文学的重要奠基者。将其逝世节点放入生平线索中，可以帮助游客理解绍兴故里只是鲁迅人生开端，而纪念馆陈列则延伸到其一生思想和文学贡献。',
        '纪念与研究': '1953年，绍兴鲁迅纪念馆建立，之后鲁迅故里逐步形成以故居遗迹、人物纪念、作品阐释、爱国主义教育和研学旅游为一体的展示体系。纪念馆和故里景区不仅保存鲁迅相关建筑与资料，也承担向公众解释鲁迅生平、作品、思想及其与绍兴关系的功能。',
    }
    for stage, event in events.items():
        set_by_name(ws, stage_col, stage, '生平事件', event)

# 4. 合并“备注”列：每个有“备注”的表，将第2行到末行合并为一个备注单元格。
#    合并前把分散备注整理为带条目名的汇总文本，避免信息丢失。
def merge_note_column(ws):
    hm = header_map(ws)
    if '备注' not in hm or ws.max_row < 2:
        return
    note_col = hm['备注']
    # 已有合并区域如覆盖备注列，先不重复处理。
    notes = []
    label_col = 2 if ws.max_column >= 2 else 1
    for r in range(2, ws.max_row + 1):
        note = ws.cell(r, note_col).value
        if note not in (None, ''):
            label = ws.cell(r, label_col).value or ws.cell(r, 1).value or f'第{r}行'
            notes.append(f'{label}：{note}')
    merged_text = '\n'.join(notes) if notes else '无特别备注；具体开放、预约、票价、交通、住宿、活动安排等动态信息，以官方公告和实时平台为准。'
    # 清空并合并。
    for r in range(2, ws.max_row + 1):
        ws.cell(r, note_col).value = None
    ws.cell(2, note_col).value = merged_text
    ws.cell(2, note_col).alignment = Alignment(vertical='top', wrap_text=True)
    ws.merge_cells(start_row=2, start_column=note_col, end_row=ws.max_row, end_column=note_col)

for ws in wb.worksheets:
    merge_note_column(ws)

# 5. 合并“01_景区总览”的“大类”列。
if '01_景区总览' in wb.sheetnames:
    ws = wb['01_景区总览']
    hm = header_map(ws)
    if '大类' in hm and ws.max_row >= 2:
        col = hm['大类']
        for r in range(2, ws.max_row + 1):
            ws.cell(r, col).value = None
        ws.cell(2, col).value = '景区总览'
        ws.cell(2, col).alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        ws.merge_cells(start_row=2, start_column=col, end_row=ws.max_row, end_column=col)

# 6. 全局格式优化。
header_fill = PatternFill('solid', fgColor='1F4E78')
header_font = Font(color='FFFFFF', bold=True)
thin = Side(style='thin', color='D9E2F3')
for ws in wb.worksheets:
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = 'A2'
    if ws.max_row > 1 and ws.max_column > 1:
        ws.auto_filter.ref = ws.dimensions
    try:
        ws.tables.clear()
    except Exception:
        pass
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = Border(top=thin, left=thin, right=thin, bottom=thin)
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical='top', wrap_text=True)
            cell.border = Border(top=thin, left=thin, right=thin, bottom=thin)
    for c in range(1, ws.max_column + 1):
        header = ws.cell(1, c).value
        letter = get_column_letter(c)
        if header in ('景区简介', '生平事件', '历史简介', '内容'):
            ws.column_dimensions[letter].width = 70
        elif header in ('备注',):
            ws.column_dimensions[letter].width = 42
        elif isinstance(header, str) and (header.startswith('来源链接') or header in ('URL', '链接')):
            ws.column_dimensions[letter].width = 16
        elif c <= 2:
            ws.column_dimensions[letter].width = 20
        else:
            ws.column_dimensions[letter].width = min(max(ws.column_dimensions[letter].width or 24, 22), 55)

wb.save(OUTPUT)
print(OUTPUT)
print('|'.join(wb.sheetnames))
if spot_sheet in wb.sheetnames:
    print(spot_sheet, wb[spot_sheet].max_row, wb[spot_sheet].max_column)
if life_sheet in wb.sheetnames:
    print(life_sheet, wb[life_sheet].max_row, wb[life_sheet].max_column)
