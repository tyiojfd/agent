import csv
import zipfile
from pathlib import Path
from urllib.parse import quote
from xml.sax.saxutils import escape

OUT_DIR = Path(r"D:\luxun\luxun_crawl_output")
IN_CSV = OUT_DIR / "鲁迅故里_小红书公开信息与实用攻略分类整理.csv"
OUT_CSV = OUT_DIR / "鲁迅故里_小红书公开信息与实用攻略分类整理_扩展版.csv"
OUT_XLSX = OUT_DIR / "鲁迅故里_小红书公开信息与实用攻略分类整理_扩展版.xlsx"

CATEGORIES = ["游览路线", "周边餐饮", "住宿参考", "最佳游玩时间段/避开人流建议", "拍照技巧", "园内商铺/文创店/书店", "公共交通", "小红书站内检索词"]
HEADERS = ["分类", "主题", "整理内容", "来源链接", "来源类型", "备注"]

def xhs_search(keyword):
    return "https://www.xiaohongshu.com/search_result?keyword=" + quote(keyword)

rows = []
if IN_CSV.exists():
    with IN_CSV.open("r", encoding="utf-8-sig", newline="") as f:
        rows.extend(list(csv.reader(f))[1:])

more = [
    # more xhs search entries
    ["小红书站内检索词", "鲁迅故里盖章", "适合查鲁迅故里主题邮局、非遗邮局、孔乙己文创店、我和我的故乡文创店等集章攻略。", xhs_search("鲁迅故里 盖章"), "小红书站内搜索入口", "小红书笔记需App/登录查看"],
    ["小红书站内检索词", "鲁迅故里邮局冰镇文学", "适合查鲁迅故里邮局“冰镇文学”雪糕、小红书话题活动、拓印体验等内容。", xhs_search("鲁迅故里邮局 冰镇文学"), "小红书站内搜索入口", "可配合绍兴网/中国邮政公开资料核对"],
    ["小红书站内检索词", "鲁迅故里旗袍", "适合查旗袍、国风、江南古城风拍照搭配和陪拍笔记。", xhs_search("鲁迅故里 旗袍"), "小红书站内搜索入口", "站内查看最新机位和服装建议"],
    ["小红书站内检索词", "绍兴两天一夜 鲁迅故里", "适合查鲁迅故里+沈园+仓桥直街+书圣故里+兰亭等组合行程。", xhs_search("绍兴两天一夜 鲁迅故里"), "小红书站内搜索入口", "适合扩展住宿/餐饮笔记"],
    ["小红书站内检索词", "鲁迅故里 黄酒奶茶", "适合查黄酒奶茶、黄酒咖啡、黄酒棒冰、绍兴特色饮品。", xhs_search("鲁迅故里 黄酒奶茶"), "小红书站内搜索入口", "适合美食饮品类补充"],
    ["小红书站内检索词", "鲁迅故里 陪拍", "适合查陪拍服务、旗袍写真、古城人像拍摄建议。", xhs_search("鲁迅故里 陪拍"), "小红书站内搜索入口", "注意甄别商业推广"],

    # route expansion
    ["游览路线", "鲁迅故里→沈园→仓桥直街→八字桥", "绍兴本地宝一日游路线建议：鲁迅故里景区、沈园、仓桥直街、八字桥串联。鲁迅故里游览约3—4小时，沈园可步行前往，仓桥直街适合晚间散步和小吃。", "https://m.sx.bendibao.com/tour/19498.shtm", "本地宝攻略", "适合绍兴古城一日游"],
    ["游览路线", "上午鲁迅故里+下午沈园+傍晚仓桥直街", "更顺路的时间安排：08:30—12:00鲁迅故里，午餐后13:00—15:00沈园，15:30后仓桥直街。适合第一次来绍兴的游客。", "https://m.sx.bendibao.com/tour/19498.shtm", "本地宝攻略", "鲁迅故里和沈园预约/开放以官方为准"],
    ["游览路线", "鲁迅故里核心景点动线", "入口景墙打卡后按鲁迅祖居、三味书屋、鲁迅故居、百草园、鲁迅纪念馆、风情园顺序游览，减少折返。", "https://m.sx.bendibao.com/tour/27882.shtm", "本地宝攻略", "适合亲子研学和课本路线"],
    ["游览路线", "文创盖章路线", "围绕鲁迅故里主题邮局、孔乙己文创店、我和我的故乡文创店等点位做盖章路线，适合小红书图文和伴手礼打卡。", "https://www.sohu.com/a/919540111_121106994", "攻略转载/含小红书图片线索", "具体盖章点以现场为准"],

    # food expansion
    ["周边餐饮", "凰仪桥饭店", "攻略称凰仪桥饭店在鲁迅西路凰仪桥下，离鲁迅故里步行约15分钟，偏本地家常菜，适合想避开纯景区店的游客。", "https://www.greentourasia.com/article/luxungulizhoubianmeishi", "美食攻略", "建议用地图确认营业状态"],
    ["周边餐饮", "高老太奶油小攀", "绍兴网介绍奶油小攀是越城老点心，高老太奶油小攀从鲁迅故里西门出来左拐几步可到，是热门打卡小吃。", "https://www.shaoxing.com.cn/ycq/p/3198579.html", "绍兴网", "甜口小吃，适合边逛边买"],
    ["周边餐饮", "诸暨次坞打面鲁迅故里旗舰店", "浙江省文旅厅报道鲁迅故里有诸暨次坞打面旗舰店，主营次坞打面，也有西施团圆饼、诸暨年糕、糖漾等特色小吃。", "https://ct.zj.gov.cn/art/2021/9/30/art_1652992_59008136.html", "浙江省文旅厅", "适合想吃面食/诸暨小吃的人"],
    ["周边餐饮", "绍兴味道绍兴菜·非遗餐厅", "地图结果显示该店在鲁迅中路227-5号，靠近鲁迅故里，适合作为绍兴菜正餐参考。", "https://www.amap.com/place/B0I0XCA9I3", "地图/餐饮", "评分和营业时间需实时查看"],
    ["周边餐饮", "越香王老汉臭豆腐", "美食攻略中提及鲁迅故里周边常见绍兴臭豆腐店，适合作为小吃体验。", "https://www.greentourasia.com/article/luxungulizhoubianmeishi", "美食攻略", "景区周边小吃店多，注意排队和价格"],
    ["周边餐饮", "卢记小先肉香酥鸡烧饼", "攻略提到该类烧饼/梅干菜烧饼适合边走边吃，可作为鲁迅故里周边小吃补充。", "https://www.greentourasia.com/article/luxungulizhoubianmeishi", "美食攻略", "以现场门店为准"],
    ["周边餐饮", "一尺花园/邵小咖等饮品", "搜索结果显示鲁迅故里附近有咖啡饮品店，如一尺花园、邵小咖等，可关注黄酒奶茶、黄酒咖啡等绍兴特色饮品。", "https://maps.apple.com/place?_provider=57879&place-id=H2710I3F97727F6A848", "地图/搜索结果", "需自行核对门店是否营业"],

    # accommodation expansion
    ["住宿参考", "开元颐居酒店（鲁迅故里地铁站仓桥直街店）", "携程结果显示可步行到鲁迅故里、沈园、仓桥直街，位置适合首次来绍兴古城游玩。", "https://m.ctrip.com/html5/hotel/hoteldetail/85396605.html", "住宿平台", "订房前看近期差评和距离"],
    ["住宿参考", "沐尘·赫隐花园设计酒店", "位于仓桥直街景区一带，靠近青藤书屋，毗邻鲁迅故里和沈园，偏设计/江南氛围住宿。", "https://hotels.ctrip.com/hotels/62251737.html", "住宿平台", "适合想住古城氛围的人"],
    ["住宿参考", "尚客优悦酒店", "搜索结果显示靠近沈园、仓桥直街，适合预算和便利性优先的游客。", "https://hotels.ctrip.com/hotels/107206521.html", "住宿平台", "注意看近期评价"],
    ["住宿参考", "安玥酒店", "Trip.com显示距离沈园约190米，靠近鲁迅故里地铁站，位置方便。", "https://my.trip.com/hotels/shaoxing-hotel-detail-71545264/ayrh-hotel/", "住宿平台", "注意卫生/性价比评价"],
    ["住宿参考", "奇遇·陶然酒店", "Trip.com显示靠近鲁迅故里地铁站，周边有绍兴师爷馆、徐渭艺术馆、青藤书屋等，适合古城游。", "https://us.trip.com/hotels/shaoxing-hotel-detail-120148083/shaoxing-lu-xun-s-hometown-adventure-taoran-hotel-cangqiao-zhijie-branch/", "住宿平台", "价格随日期波动"],
    ["住宿参考", "花筑·幽兰别院", "位于仓桥直街鲁迅故里片区，偏江南庭院/民宿风，适合想体验古城氛围的游客。", "https://hotels.corporatetravel.ctrip.com/hotels/85219585.html", "住宿平台", "注意临街噪音和停车"],
    ["住宿参考", "柒遇·智能观影酒店", "位于仓桥直街与府山横街附近，距鲁迅故里和沈园有一定距离，适合预算型/观影酒店偏好。", "https://www.klook.com/hotels/detail/1068342/", "住宿平台", "需核对步行/打车距离"],

    # timing/crowd expansion
    ["最佳游玩时间段/避开人流建议", "9:30前到达", "部分攻略建议9:30前到达鲁迅故里入口与景墙，可减少旅行团和散客人流干扰，适合拍照。", "https://m.sx.bendibao.com/tour/19498.shtm", "攻略/经验整理", "高峰期仍需提前预约"],
    ["最佳游玩时间段/避开人流建议", "节假日优先公共交通", "鲁迅故里和古城核心区节假日人流、车流较大，建议优先地铁/公交，减少停车和拥堵时间。", "https://jt.dushiquan.net/shaoxing/station_5262/", "交通信息", "自驾需提前查停车"],
    ["最佳游玩时间段/避开人流建议", "仓桥直街放傍晚", "仓桥直街全年全天开放、免费，适合作为鲁迅故里和沈园后的傍晚/夜间收尾。", "https://sx.bendibao.com/jingdian/cangqiaozhijie/", "本地宝景点", "夜间更有古城氛围"],
    ["最佳游玩时间段/避开人流建议", "景区预约全满时调整计划", "绍兴网曾报道鲁迅故里景区预约全满情况；若当天约满，可先去沈园、仓桥直街、书圣故里等周边点位。", "https://www.shaoxing.com.cn/ycq/p/3121572.html", "绍兴网", "节假日务必提前预约"],
    ["最佳游玩时间段/避开人流建议", "雨天/淡季策略", "雨天或淡季人流相对少，适合拍江南水乡氛围，但室外百草园、街区拍照需带伞并注意路滑。", xhs_search("鲁迅故里 雨天 拍照"), "小红书站内搜索入口", "具体体验需查看小红书实时笔记"],

    # photo expansion
    ["拍照技巧", "鲁迅夹烟景墙位置", "绍兴网报道景墙位于鲁迅故里东入口，约高4.5米、长15米，包含鲁迅画像和“鲁迅故里”字样，是标志性打卡点。", "https://www.shaoxing.com.cn/p/3360222.html", "绍兴网", "注意文明拍摄"],
    ["拍照技巧", "网红墙争议与文明拍摄", "中新网报道鲁迅夹烟网红打卡墙引发过模仿动作争议；拍照时建议避免不雅动作，尊重纪念地氛围。", "https://www.chinanews.com.cn/sh/2025/08-26/10471475.shtml", "中新网", "适合写入拍照注意事项"],
    ["拍照技巧", "旗袍/国风拍摄", "公开搜索结果显示小红书有#鲁迅故里旗袍#、#鲁迅故里陪拍#等话题线索；适合白墙黑瓦、青石板路、乌篷船水巷场景。", "https://www.researchgate.net/publication/392860595_Study_on_the_Influence_of_Lu_Xun%27s_Hometown", "论文/搜索摘要线索", "具体机位建议在小红书站内查"],
    ["拍照技巧", "鲁迅故里邮局拍照", "主题邮局有黄铜邮筒、明信片、印章、文创雪糕等元素，适合细节照和集章图文。", "https://www.chinapost.com.cn/html1/report/24032/112-1.htm", "中国邮政", "可搭配小红书话题"],
    ["拍照技巧", "朝花夕拾咖啡店拍照", "店内有迅哥盲盒咖啡、鲁迅系列甜品、文创周边和庭院场景，适合饮品+文创+庭院风格照片。", "https://www.chinanews.com.cn/sh/2025/05-30/10424916.shtml", "中新网", "注意店内拍摄规则"],

    # shops/culture expansion
    ["园内商铺/文创店/书店", "浙江非遗邮局·鲁迅主题邮局", "中国邮政介绍该邮局位于绍兴市越城区中兴南路171号，融合鲁迅故里、邮政文化和文创产品，可盖章、买明信片、纪念币、冰箱贴、手办、饮品等。", "https://www.chinapost.com.cn/html1/report/24032/112-1.htm", "中国邮政", "盖章/伴手礼重点点位"],
    ["园内商铺/文创店/书店", "鲁迅故里主题邮局小红书打卡", "中国邮政转载绍兴日报文章称老邮局因小红书打卡出圈，转型为文创、咖啡、打卡式主题邮局。", "https://www.chinapost.com.cn/html1/report/211140/4845-1.htm", "中国邮政/绍兴日报", "与小红书关联较强"],
    ["园内商铺/文创店/书店", "冰镇文学雪糕", "绍兴网报道鲁迅故里邮局推出“冰镇文学”系列雪糕，雪糕表面有《呐喊》《朝花夕拾》《新青年》等鲁迅元素，并有小红书话题活动。", "https://www.shaoxing.com.cn/xinwen/p/3339659.html", "绍兴网", "活动日期以原文/现场为准"],
    ["园内商铺/文创店/书店", "冰镇文学小红书互动", "购买雪糕后拍照或视频发小红书，带话题#鲁迅故里邮局冰镇文学并@浙江非遗邮局鲁迅故里邮局，可领取拓印册并体验拓印（活动以原文时间为准）。", "https://www.shaoxing.com.cn/xinwen/p/3339659.html", "绍兴网", "可作为小红书传播案例"],
    ["园内商铺/文创店/书店", "鲁迅主题邮局地址/时间/价格线索", "搜狐文创文章称浙江非遗邮局·鲁迅主题邮局在鲁迅故里东门入口黄铜邮筒处，并提到雪糕25元/支、营业时间8:00—21:00。", "https://www.sohu.com/a/927754005_121106994", "搜狐/文创攻略", "需现场核对价格时间"],
    ["园内商铺/文创店/书店", "朝花夕拾·文创咖啡供销社", "中新网报道人民文学出版社“朝花夕拾·文创咖啡供销社”入驻鲁迅故里，有迅哥盲盒印花咖啡、鲁迅系列甜品、毛绒玩具、咖啡杯等。", "https://www.chinanews.com.cn/sh/2025/05-30/10424916.shtml", "中新网", "文学+咖啡+文创空间"],
    ["园内商铺/文创店/书店", "朝花夕拾旗舰店位置", "中国出版传媒商报称朝花夕拾文创咖啡供销社·鲁迅故里旗舰店在绍兴鲁迅故里景区作家楼区域开业，定位文学+咖啡+文创沉浸式空间。", "https://www.cbbr.com.cn/contents/533/100036.html", "出版传媒商报", "位置以现场导览为准"],
    ["园内商铺/文创店/书店", "迅哥咖啡/鲁迅主题文创", "中国青年报介绍该店推出“朝花夕拾”鲁迅主题文创系列产品，将鲁迅作品元素与咖啡创意结合。", "https://m.cyol.com/gb/articles/2025-05/28/content_xay4ypSVxa.html", "中国青年报", "适合休息+拍照"],
    ["园内商铺/文创店/书店", "鲁迅文化IP文创", "新华网报道鲁迅故里与设计团队合作，开发以鲁迅及其文学作品为主题的文创纪念品和特色餐饮单品。", "https://www.news.cn/culture/20251024/7cc2d81a78af433a8e8eb5ef71bd9a7d/c.html", "新华网", "适合总结文创趋势"],
    ["园内商铺/文创店/书店", "茴香豆/黄酒棒冰/早字冰箱贴/Q版鲁迅", "央视网报道鲁迅故里围绕鲁迅IP推出孔乙己茴香豆、黄酒棒冰、“早”字冰箱贴、Q版鲁迅形象商品等。", "https://news.cctv.com/2019/06/28/ARTIEVDkFKnQUEP8OnHGaeOv190628.shtml", "央视网", "早期文创案例"],
    ["园内商铺/文创店/书店", "孔乙己文创店/我和我的故乡文创店", "盖章攻略类文章提到孔乙己文创店、“我和我的故乡”文创店和鲁迅故里主题邮局等盖章/文创点。", "https://www.sohu.com/a/919540111_121106994", "攻略转载/含小红书图片线索", "需现场核对店铺营业"],
]

# dedupe by category + theme + source link
seen = set()
dedup = []
for r in rows + more:
    key = (r[0], r[1], r[3])
    if key in seen:
        continue
    seen.add(key)
    dedup.append(r)
rows = dedup

# write csv
with OUT_CSV.open("w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(HEADERS)
    w.writerows(rows)

def col_name(n):
    s = ""
    while n:
        n, rem = divmod(n - 1, 26)
        s = chr(65 + rem) + s
    return s

def cell_xml(ref, value, is_formula=False):
    value = "" if value is None else str(value)
    if is_formula:
        return f'<c r="{ref}"><f>{escape(value)}</f></c>'
    return f'<c r="{ref}" t="inlineStr"><is><t xml:space="preserve">{escape(value)}</t></is></c>'

def hyperlink(url):
    u = (url or "").replace('"', '""')
    return f'HYPERLINK("{u}","{u}")'

def sheet_xml(sheet_rows, link_col=None):
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>']
    for r_idx, row in enumerate(sheet_rows, 1):
        out.append(f'<row r="{r_idx}">')
        for c_idx, val in enumerate(row, 1):
            is_formula = link_col is not None and r_idx > 1 and c_idx == link_col and val
            if is_formula:
                val = hyperlink(val)
            out.append(cell_xml(f"{col_name(c_idx)}{r_idx}", val, is_formula))
        out.append('</row>')
    out.append('</sheetData></worksheet>')
    return "".join(out)

sheets = [("分类总表", [HEADERS] + rows, 4)]
for cat in CATEGORIES:
    cat_rows = [r for r in rows if r[0] == cat]
    sheets.append((cat[:31], [HEADERS] + cat_rows, 4))
summary = [["分类", "条数"], *[[cat, sum(1 for r in rows if r[0] == cat)] for cat in CATEGORIES], ["总计", len(rows)], ["说明", "扩展版：公开网页搜索未能稳定抓取小红书笔记全文；本表整合小红书站内搜索入口、公开搜索摘要、官方/新闻/攻略/地图/住宿平台来源。"]]
sheets.append(("统计说明", summary, None))

with zipfile.ZipFile(OUT_XLSX, "w", zipfile.ZIP_DEFLATED) as z:
    overrides = "".join([f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(1, len(sheets)+1)])
    z.writestr("[Content_Types].xml", f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>{overrides}<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>''')
    z.writestr("_rels/.rels", '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>''')
    rels = "".join([f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i}.xml"/>' for i in range(1, len(sheets)+1)])
    rels += f'<Relationship Id="rId{len(sheets)+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
    z.writestr("xl/_rels/workbook.xml.rels", f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">{rels}</Relationships>''')
    sheet_tags = "".join([f'<sheet name="{escape(name)}" sheetId="{i}" r:id="rId{i}"/>' for i, (name, _, _) in enumerate(sheets, 1)])
    z.writestr("xl/workbook.xml", f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>{sheet_tags}</sheets></workbook>''')
    z.writestr("xl/styles.xml", '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts><fills count="1"><fill><patternFill patternType="none"/></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs></styleSheet>''')
    for i, (_, sheet_rows, link_col) in enumerate(sheets, 1):
        z.writestr(f"xl/worksheets/sheet{i}.xml", sheet_xml(sheet_rows, link_col))

print("DONE")
print("xlsx", OUT_XLSX)
print("csv", OUT_CSV)
print("rows", len(rows))
for cat in CATEGORIES:
    print(cat, sum(1 for r in rows if r[0] == cat))
