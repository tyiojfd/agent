from pathlib import Path
from collections import Counter
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

BASE_XLSX = Path(r'D:\python学习\baidupc\鲁迅故里景区资料整理_最终优化版.xlsx')
XHS_SCRIPT = Path(r'D:\python学习\baidupc\scripts\04_小红书增强\extend_xhs_luxun_guide_excel.py')
OUTPUT = Path(r'D:\python学习\baidupc\鲁迅故里景区资料整理_最终优化版_合并小红书.xlsx')

# 读取 extend_xhs_luxun_guide_excel.py 中的已整理小红书/攻略扩展数据。
# 只执行写文件前的数据构造部分，避免依赖原脚本里的 D:\luxun\luxun_crawl_output 目录。
code = XHS_SCRIPT.read_text(encoding='utf-8')
prefix = code.split('# dedupe by category')[0]
ns = {}
exec(prefix, ns)
headers = ns['HEADERS']
rows = ns.get('rows', []) + ns.get('more', [])

# 去重：分类 + 主题 + 来源链接。
seen = set()
deduped = []
for row in rows:
    if len(row) < len(headers):
        row = row + [''] * (len(headers) - len(row))
    key = (row[0], row[1], row[3])
    if key in seen:
        continue
    seen.add(key)
    deduped.append(row[:len(headers)])
rows = deduped

wb = load_workbook(BASE_XLSX)

# 避免重复运行时残留旧的小红书表。
for name in ['07_小红书数据汇总', '08_小红书分类统计']:
    if name in wb.sheetnames:
        del wb[name]

header_fill = PatternFill('solid', fgColor='1F4E78')
header_font = Font(color='FFFFFF', bold=True)
thin = Side(style='thin', color='D9E2F3')

def excel_quote(s: str) -> str:
    return s.replace('"', '""')

def hyperlink_formula(url: str, label: str = '打开链接') -> str:
    return f'=HYPERLINK("{excel_quote(url)}","{excel_quote(label)}")'

def style_sheet(ws):
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = 'A2'
    if ws.max_row > 1 and ws.max_column > 1:
        ws.auto_filter.ref = ws.dimensions
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = Border(top=thin, left=thin, right=thin, bottom=thin)
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            value = '' if cell.value is None else str(cell.value)
            if value.startswith('=HYPERLINK('):
                cell.font = Font(color='0563C1', underline='single')
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            elif len(value) <= 28:
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            else:
                cell.alignment = Alignment(horizontal='left', vertical='top', wrap_text=True)
            cell.border = Border(top=thin, left=thin, right=thin, bottom=thin)
    for c in range(1, ws.max_column + 1):
        header = ws.cell(1, c).value
        letter = get_column_letter(c)
        if header in ('整理内容', '说明', '备注'):
            ws.column_dimensions[letter].width = 64 if header == '整理内容' else 42
        elif header in ('来源链接',):
            ws.column_dimensions[letter].width = 16
        elif header in ('来源类型', '分类', '主题'):
            ws.column_dimensions[letter].width = 24
        else:
            ws.column_dimensions[letter].width = 18

# 07 小红书数据汇总
ws = wb.create_sheet('07_小红书数据汇总')
ws.append(headers)
for row in rows:
    out = row.copy()
    # 来源链接列用 HYPERLINK 公式，避免纯文本不可点击。
    if out[3]:
        out[3] = hyperlink_formula(out[3], '打开来源')
    ws.append(out)
style_sheet(ws)

# 08 分类统计与合并说明
counter = Counter(row[0] for row in rows)
ws2 = wb.create_sheet('08_小红书分类统计')
ws2.append(['项目', '内容'])
ws2.append(['合并来源', 'extend_xhs_luxun_guide_excel.py 中的公开信息与小红书站内检索入口扩展数据'])
ws2.append(['合并方式', '在原有最终优化版 Excel 后新增“07_小红书数据汇总”和本统计说明表；原有景区总览、核心景点、活动、生平、实用信息、来源清单保持不删改。'])
ws2.append(['数据说明', '小红书笔记全文通常需要 App/登录查看，公开网页抓取不稳定；本次汇总以小红书站内搜索入口、公开搜索摘要、官方/新闻/攻略/地图/住宿平台链接作为可核验补充。'])
ws2.append(['总条数', len(rows)])
for category, count in counter.items():
    ws2.append([category, count])
style_sheet(ws2)

wb.save(OUTPUT)
print(OUTPUT)
print('xhs_rows', len(rows))
print('categories', dict(counter))
print('sheets', '|'.join(wb.sheetnames))
