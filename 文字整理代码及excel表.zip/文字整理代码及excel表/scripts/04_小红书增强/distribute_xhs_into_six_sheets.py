import re
from pathlib import Path
from collections import defaultdict
from copy import copy
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

INPUT = Path(r'D:\python学习\baidupc\鲁迅故里景区资料整理_最终优化版_合并小红书.xlsx')
OUTPUT = Path(r'D:\python学习\baidupc\鲁迅故里景区资料整理_小红书汇总增强版.xlsx')

wb = load_workbook(INPUT, data_only=False)

XHS_SHEET = '07_小红书数据汇总'
if XHS_SHEET not in wb.sheetnames:
    raise RuntimeError('未找到 07_小红书数据汇总，请先生成合并小红书版本。')

# ---------- helpers ----------
def header_map(ws):
    return {ws.cell(1, c).value: c for c in range(1, ws.max_column + 1)}

def excel_quote(s: str) -> str:
    return str(s).replace('"', '""')

def hyperlink_formula(url: str, label: str = '打开来源') -> str:
    return f'=HYPERLINK("{excel_quote(url)}","{excel_quote(label)}")'

def parse_hyperlink_formula(value):
    if not isinstance(value, str):
        return value or ''
    m = re.match(r'=HYPERLINK\("((?:""|[^"])*)"\s*,', value)
    if m:
        return m.group(1).replace('""', '"')
    return value

def unmerge_and_fill(ws):
    ranges = list(ws.merged_cells.ranges)
    for rng in ranges:
        val = ws.cell(rng.min_row, rng.min_col).value
        ws.unmerge_cells(str(rng))
        for r in range(rng.min_row, rng.max_row + 1):
            for c in range(rng.min_col, rng.max_col + 1):
                ws.cell(r, c).value = val

def append_row_by_headers(ws, row_dict):
    hm = header_map(ws)
    r = ws.max_row + 1
    for h, v in row_dict.items():
        if h in hm:
            ws.cell(r, hm[h]).value = v
    return r

def set_cell_by_match(ws, match_header, match_value, target_header, value):
    hm = header_map(ws)
    if match_header not in hm or target_header not in hm:
        return False
    for r in range(2, ws.max_row + 1):
        if ws.cell(r, hm[match_header]).value == match_value:
            ws.cell(r, hm[target_header]).value = value
            return True
    return False

def append_cell_by_match(ws, match_header, match_value, target_header, addition):
    hm = header_map(ws)
    if match_header not in hm or target_header not in hm:
        return False
    for r in range(2, ws.max_row + 1):
        if ws.cell(r, hm[match_header]).value == match_value:
            cell = ws.cell(r, hm[target_header])
            old = cell.value or ''
            if addition not in old:
                cell.value = (old.rstrip('。') + '。' if old else '') + addition
            return True
    return False

def put_first_empty_source_link(ws, row_match_header, row_match_value, url, label='打开补充来源'):
    hm = header_map(ws)
    if row_match_header not in hm:
        return False
    for r in range(2, ws.max_row + 1):
        if ws.cell(r, hm[row_match_header]).value == row_match_value:
            link_cols = [c for h, c in hm.items() if isinstance(h, str) and h.startswith('来源链接')]
            for c in sorted(link_cols):
                val = ws.cell(r, c).value
                if not val:
                    ws.cell(r, c).value = hyperlink_formula(url, label)
                    return True
            return False
    return False

def merge_same_values(ws, header_name):
    hm = header_map(ws)
    col = hm.get(header_name)
    if not col or ws.max_row < 2:
        return
    start = 2
    current = ws.cell(start, col).value
    for r in range(3, ws.max_row + 2):
        value = ws.cell(r, col).value if r <= ws.max_row else None
        if value != current:
            end = r - 1
            if current not in (None, '') and end > start:
                ws.merge_cells(start_row=start, start_column=col, end_row=end, end_column=col)
                ws.cell(start, col).alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            elif current not in (None, ''):
                ws.cell(start, col).alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            start = r
            current = value

def merge_note_column(ws):
    hm = header_map(ws)
    col = hm.get('备注')
    if not col or ws.max_row < 2:
        return
    notes = []
    label_col = 2 if ws.max_column >= 2 else 1
    for r in range(2, ws.max_row + 1):
        note = ws.cell(r, col).value
        if note not in (None, ''):
            label = ws.cell(r, label_col).value or ws.cell(r, 1).value or f'第{r}行'
            line = f'{label}：{note}'
            if line not in notes:
                notes.append(line)
    for r in range(2, ws.max_row + 1):
        ws.cell(r, col).value = None
    ws.cell(2, col).value = '\n'.join(notes) if notes else '无特别备注；动态信息以官方公告、实时地图、住宿/餐饮平台和小红书站内最新笔记为准。'
    ws.merge_cells(start_row=2, start_column=col, end_row=ws.max_row, end_column=col)
    ws.cell(2, col).alignment = Alignment(vertical='top', wrap_text=True)

# ---------- load XHS rows ----------
xhs_ws = wb[XHS_SHEET]
xhs_headers = [xhs_ws.cell(1, c).value for c in range(1, xhs_ws.max_column + 1)]
xhs_hm = {h: i + 1 for i, h in enumerate(xhs_headers)}
xhs_rows = []
for r in range(2, xhs_ws.max_row + 1):
    item = {}
    for h in xhs_headers:
        val = xhs_ws.cell(r, xhs_hm[h]).value
        if h == '来源链接':
            val = parse_hyperlink_formula(val)
        item[h] = val or ''
    if item.get('分类') or item.get('主题'):
        xhs_rows.append(item)

by_cat = defaultdict(list)
for item in xhs_rows:
    by_cat[item['分类']].append(item)

# Before editing sheets with merged cells, unmerge/fill relevant sheets.
for s in ['01_景区总览', '02_鲁迅故里核心景点介绍', '03_活动', '04_鲁迅生平', '05_实用信息', '06_来源清单']:
    if s in wb.sheetnames:
        unmerge_and_fill(wb[s])

# ---------- 01 景区总览 ----------
if '01_景区总览' in wb.sheetnames:
    ws = wb['01_景区总览']
    additions = [
        ('小红书/攻略补充维度', '小红书扩展数据集中反映游客更关注“怎么逛、在哪吃、住哪里、怎么拍、买什么文创、如何避开人流”等实用问题，可作为官方景区信息之外的游客体验补充。', '小红书数据汇总；本地宝/绍兴网/中国邮政/旅游平台等公开来源'),
        ('热门联游组合', '游客攻略中高频出现“鲁迅故里→沈园→仓桥直街→八字桥”或“上午鲁迅故里、下午沈园、傍晚仓桥直街”的绍兴古城联游方式，适合第一次来绍兴的半日到一日游。', '小红书数据汇总；绍兴本地宝'),
        ('文创与社交传播', '鲁迅主题邮局、盖章路线、“冰镇文学”雪糕、朝花夕拾文创咖啡、鲁迅IP周边和东入口景墙等，构成小红书用户常见的打卡、拍照、种草内容。', '小红书数据汇总；中国邮政/绍兴网/中新网/新华网/央视网'),
    ]
    for item, content, source_name in additions:
        append_row_by_headers(ws, {
            '大类': '景区总览', '项目': item, '内容': content,
            '来源名称': source_name,
            '来源链接1': '', '来源链接2': '', '来源链接3': '',
            '备注': '小红书数据已按主题分发到活动、实用信息、来源清单等表中。'
        })

# ---------- 02 核心景点介绍：用小红书/攻略数据补充现有景点文字 ----------
if '02_鲁迅故里核心景点介绍' in wb.sheetnames:
    ws = wb['02_鲁迅故里核心景点介绍']
    append_cell_by_match(ws, '景点名称', '鲁迅故里景区', '主要看点', '小红书/公开攻略补充的游客关注点包括东入口鲁迅景墙、鲁迅故里主题邮局、盖章路线、冰镇文学雪糕、朝花夕拾文创咖啡、绍兴小吃和鲁迅IP文创。')
    append_cell_by_match(ws, '景点名称', '鲁迅故里景区', '游览提示', '游客攻略建议节假日提前预约，尽量9:30前到达核心入口与景墙区域；若鲁迅故里预约已满，可先调整到沈园、仓桥直街、书圣故里等周边点位。')
    append_cell_by_match(ws, '景点名称', '鲁迅故里步行街/风情街', '景区简介', '小红书扩展数据中，步行街/风情街还承担“吃、拍、买、盖章”的游览功能，常与鲁迅主题邮局、孔乙己文创店、我和我的故乡文创店、朝花夕拾文创咖啡、黄酒饮品和周边小吃一起出现。')
    append_cell_by_match(ws, '景点名称', '鲁迅故里步行街/风情街', '主要看点', '可重点关注浙江非遗邮局·鲁迅主题邮局、黄铜邮筒、明信片与集章、冰镇文学雪糕、朝花夕拾文创咖啡、黄酒棒冰、Q版鲁迅/“早”字等鲁迅文化IP文创。')
    append_cell_by_match(ws, '景点名称', '鲁迅故里步行街/风情街', '游览提示', '文创、盖章、饮品和餐饮点位更新较快，小红书适合查询最新笔记，但营业时间、价格、排队情况仍需以现场和地图平台为准。')
    append_cell_by_match(ws, '景点名称', '沈园', '游览提示', '游客路线补充：沈园适合安排在鲁迅故里之后，之后可继续步行或换乘前往仓桥直街、八字桥等古城点位；若观看夜间演艺，需单独确认购票与入园时间。')
    # clickable supporting source links placed into rows where empty columns exist
    source_examples = {
        '鲁迅故里景区': ['https://www.shaoxing.com.cn/p/3360222.html', 'https://www.chinapost.com.cn/html1/report/24032/112-1.htm'],
        '鲁迅故里步行街/风情街': ['https://www.shaoxing.com.cn/xinwen/p/3339659.html', 'https://www.chinanews.com.cn/sh/2025/05-30/10424916.shtml'],
        '沈园': ['https://m.sx.bendibao.com/tour/19498.shtm'],
    }
    for spot, urls in source_examples.items():
        for url in urls:
            put_first_empty_source_link(ws, '景点名称', spot, url)

# ---------- 03 活动：抽取小红书中适合“活动/体验”的内容 ----------
if '03_活动' in wb.sheetnames:
    ws = wb['03_活动']
    activity_additions = [
        ('鲁迅故里文创盖章路线', '鲁迅故里主题邮局、孔乙己文创店、我和我的故乡文创店等点位', '以现场营业和小红书最新笔记为准', '围绕主题邮局、文创店、明信片、印章和伴手礼形成盖章路线，适合图文打卡和亲子互动。', '把鲁迅文化IP、邮政文化和古城街区消费体验结合起来，是小红书用户常见的轻量化游览玩法。', '亲子、年轻游客、文创/集章爱好者', '小红书数据汇总；中国邮政/搜狐攻略等公开来源', 'https://www.chinapost.com.cn/html1/report/24032/112-1.htm', '小红书笔记需App/登录查看，具体盖章点以现场为准'),
        ('“冰镇文学”雪糕打卡', '鲁迅故里邮局及相关文创点', '活动和售卖以现场/原公告为准', '围绕《呐喊》《朝花夕拾》《新青年》等鲁迅元素雪糕拍照、发小红书话题、拓印体验等进行传播。', '将鲁迅文学符号转化为夏季饮食文创和社交平台传播素材。', '小红书用户、亲子、文创游客', '小红书数据汇总；绍兴网', 'https://www.shaoxing.com.cn/xinwen/p/3339659.html', '价格、活动日期和赠品以现场为准'),
        ('鲁迅故里景墙文明打卡', '鲁迅故里东入口景墙', '全天户外打卡，按景区现场秩序为准', '东入口鲁迅画像与“鲁迅故里”字样景墙是标志性拍照点，但公开报道也提醒注意文明拍摄，避免不雅模仿。', '体现鲁迅故里在社交平台上的视觉传播，同时需要尊重纪念地氛围。', '普通游客、摄影/短视频用户', '小红书数据汇总；绍兴网/中新网', 'https://www.shaoxing.com.cn/p/3360222.html', '拍照应遵守现场秩序和文明参观要求'),
        ('朝花夕拾文创咖啡体验', '鲁迅故里景区作家楼区域等相关空间', '以门店营业时间为准', '体验鲁迅主题咖啡、甜品、毛绒玩具、咖啡杯等文学+咖啡+文创产品。', '把鲁迅作品元素与当代咖啡消费、文创零售和休憩空间结合。', '年轻游客、文创消费人群、拍照打卡游客', '小红书数据汇总；中新网/出版传媒商报/中国青年报', 'https://www.chinanews.com.cn/sh/2025/05-30/10424916.shtml', '店内拍摄和消费信息以现场为准'),
        ('旗袍/国风拍照', '白墙黑瓦、青石板路、乌篷船水巷、鲁迅中路街区', '建议早到或淡季错峰', '小红书检索词显示“鲁迅故里旗袍”“鲁迅故里陪拍”等内容适合查询服装、陪拍、机位和姿势建议。', '利用绍兴古城和鲁迅故里街区风貌形成国风人像拍摄体验。', '写真游客、情侣/闺蜜出游、国风爱好者', '小红书站内检索入口', 'https://www.xiaohongshu.com/search_result?keyword=%E9%B2%81%E8%BF%85%E6%95%85%E9%87%8C%20%E6%97%97%E8%A2%8D', '注意甄别商业推广，文明拍摄'),
    ]
    for a in activity_additions:
        append_row_by_headers(ws, {
            '活动名称': a[0], '地点': a[1], '时间/频次': a[2], '活动内容': a[3], '文化意义': a[4], '适合人群': a[5],
            '来源名称': a[6], '来源链接1': hyperlink_formula(a[7], '打开来源'), '来源链接2': '', '备注': a[8]
        })

# ---------- 04 鲁迅生平：补充当代传播/纪念维度 ----------
if '04_鲁迅生平' in wb.sheetnames:
    ws = wb['04_鲁迅生平']
    append_row_by_headers(ws, {
        '阶段': '当代传播与文创延展', '时间': '近年', '地点': '鲁迅故里街区、主题邮局、文创咖啡、社交平台',
        '生平事件': '这不是鲁迅本人生平事件，而是鲁迅文化在当代景区传播中的延展：小红书和公开报道中常见鲁迅主题邮局、集章、冰镇文学雪糕、朝花夕拾文创咖啡、Q版鲁迅形象、黄酒棒冰、“早”字冰箱贴、景墙打卡等内容。它们把鲁迅作品、人物形象和绍兴地方风物转化为可拍照、可购买、可分享的文旅体验。',
        '与景区/展陈关系': '可作为“纪念与研究”之外的当代传播补充，说明鲁迅故里不仅保存故居和文物，也通过文创、邮政、咖啡、社交平台打卡等方式触达年轻游客。',
        '来源名称': '小红书数据汇总；中国邮政/绍兴网/中新网/新华网/央视网',
        '来源链接1': hyperlink_formula('https://www.chinapost.com.cn/html1/report/24032/112-1.htm', '打开来源'),
        '来源链接2': hyperlink_formula('https://www.news.cn/culture/20251024/7cc2d81a78af433a8e8eb5ef71bd9a7d/c.html', '打开来源'),
        '备注': '为传播延展内容，不属于鲁迅本人生平事实。'
    })

# ---------- 05 实用信息：把 07 全量按类别映射进来 ----------
if '05_实用信息' in wb.sheetnames:
    ws = wb['05_实用信息']
    category_map = {
        '游览路线': '游览路线',
        '周边餐饮': '美食',
        '住宿参考': '住宿',
        '最佳游玩时间段/避开人流建议': '游览时间/避峰',
        '拍照技巧': '拍照打卡',
        '园内商铺/文创店/书店': '文创/商铺',
        '公共交通': '交通',
        '小红书站内检索词': '小红书检索词',
    }
    for item in xhs_rows:
        cat = category_map.get(item['分类'], item['分类'])
        url = item.get('来源链接', '')
        append_row_by_headers(ws, {
            '类别': cat,
            '项目': item.get('主题', ''),
            '内容': item.get('整理内容', ''),
            '建议': item.get('备注', ''),
            '来源名称': f"小红书数据汇总；{item.get('来源类型', '')}".strip('；'),
            '来源链接1': hyperlink_formula(url, '打开来源') if url else '',
            '来源链接2': '', '来源链接3': '',
            '备注': '由07小红书数据汇总分发补充；小红书笔记和门店信息需以实时页面/现场为准。'
        })

# ---------- 06 来源清单：追加 07 中的新来源 ----------
if '06_来源清单' in wb.sheetnames:
    ws = wb['06_来源清单']
    hm = header_map(ws)
    existing_urls = set()
    if 'URL' in hm:
        for r in range(2, ws.max_row + 1):
            existing_urls.add(parse_hyperlink_formula(ws.cell(r, hm['URL']).value))
    idx_col = hm.get('序号', 1)
    max_idx = 0
    for r in range(2, ws.max_row + 1):
        try:
            max_idx = max(max_idx, int(ws.cell(r, idx_col).value or 0))
        except Exception:
            pass
    for item in xhs_rows:
        url = item.get('来源链接', '')
        if not url or url in existing_urls:
            continue
        existing_urls.add(url)
        max_idx += 1
        append_row_by_headers(ws, {
            '序号': max_idx,
            '来源名称': item.get('主题', ''),
            '来源类型': item.get('来源类型', '') or '小红书/公开攻略补充',
            'URL': hyperlink_formula(url, '打开链接'),
            '可信度/使用说明': f"来自07小红书数据汇总的补充来源；对应分类：{item.get('分类','')}。{item.get('备注','')}"
        })

# 07/08 已被汇总到前六张表，删除汇总与统计表，保留前六表。
for name in ['07_小红书数据汇总', '08_小红书分类统计']:
    if name in wb.sheetnames:
        del wb[name]

# ---------- formatting, merges ----------
header_fill = PatternFill('solid', fgColor='1F4E78')
header_font = Font(color='FFFFFF', bold=True)
thin = Side(style='thin', color='D9E2F3')
LONG_HEADERS = {'内容', '景区简介', '历史简介', '主要看点', '与鲁迅/作品关系', '游览提示', '活动内容', '文化意义', '生平事件', '与景区/展陈关系', '建议', '可信度/使用说明'}

# re-merge 01 大类 and any note columns; re-merge 05 类别 after additions.
if '01_景区总览' in wb.sheetnames:
    merge_same_values(wb['01_景区总览'], '大类')
for ws in wb.worksheets:
    # merge notes at the end so appended notes are included.
    merge_note_column(ws)
if '05_实用信息' in wb.sheetnames:
    merge_same_values(wb['05_实用信息'], '类别')

for ws in wb.worksheets:
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = 'A2'
    if ws.max_row > 1 and ws.max_column > 1:
        ws.auto_filter.ref = ws.dimensions
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = Border(top=thin, left=thin, right=thin, bottom=thin)
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            value = '' if cell.value is None else str(cell.value)
            header = ws.cell(1, cell.column).value
            if value.startswith('=HYPERLINK('):
                cell.font = Font(color='0563C1', underline='single')
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            elif header in LONG_HEADERS:
                cell.alignment = Alignment(horizontal='left', vertical='top', wrap_text=True)
            elif len(value) <= 28:
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            else:
                cell.alignment = Alignment(horizontal='left', vertical='top', wrap_text=True)
            cell.border = Border(top=thin, left=thin, right=thin, bottom=thin)
    # Ensure merged left columns centered.
    hm = header_map(ws)
    for header in ['大类', '类别']:
        if header in hm:
            for rng in ws.merged_cells.ranges:
                if rng.min_col == hm[header] and rng.max_col == hm[header]:
                    ws.cell(rng.min_row, rng.min_col).alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    for c in range(1, ws.max_column + 1):
        header = ws.cell(1, c).value
        letter = get_column_letter(c)
        if header in ('景区简介', '历史简介', '生平事件', '内容', '整理内容'):
            ws.column_dimensions[letter].width = 72
        elif header in ('备注',):
            ws.column_dimensions[letter].width = 46
        elif isinstance(header, str) and (header.startswith('来源链接') or header in ('URL', '链接')):
            ws.column_dimensions[letter].width = 16
        elif header in ('景点名称', '类别', '阶段', '活动名称', '项目', '主题'):
            ws.column_dimensions[letter].width = 22
        else:
            ws.column_dimensions[letter].width = min(max(ws.column_dimensions[letter].width or 24, 20), 55)

wb.save(OUTPUT)
print(OUTPUT)
print('distributed_xhs_rows', len(xhs_rows))
print('|'.join(wb.sheetnames))
if '05_实用信息' in wb.sheetnames:
    print('05 rows', wb['05_实用信息'].max_row)
if '06_来源清单' in wb.sheetnames:
    print('06 rows', wb['06_来源清单'].max_row)
