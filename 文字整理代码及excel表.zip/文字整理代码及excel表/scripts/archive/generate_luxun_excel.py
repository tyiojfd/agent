from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo
from datetime import date

OUTPUT = '鲁迅故里景区资料整理.xlsx'
SCRAPE_DATE = '2026-06-13'

sources = {
    'official_intro': ('绍兴鲁迅故里沈园景区官网：景区介绍', 'https://sxlxmuseum.com/jqjs.htm', '官方'),
    'official_visit': ('绍兴鲁迅故里沈园景区官网：鲁迅故里参观指南', 'https://sxlxmuseum.com/cgzn/lxgl.htm', '官方'),
    'sx_tour_area': ('绍兴市文化旅游集团官网：鲁迅故里·沈园景区', 'https://www.shaoxingtour.cn/rwjq/lxgl_syjq.htm', '官方/文旅集团'),
    'sx_tour_lxgl': ('绍兴市文化旅游集团官网：绍兴鲁迅故里景区', 'https://www.shaoxingtour.cn/info/1031/1260.htm', '官方/文旅集团'),
    'sx_tour_sanwei': ('绍兴市文化旅游集团官网：三味书屋（寿家台门）', 'https://www.shaoxingtour.cn/info/1031/1257.htm', '官方/文旅集团'),
    'sx_tour_guzhai': ('绍兴市文化旅游集团官网：鲁迅故居（周家新台门）', 'https://www.shaoxingtour.cn/info/1031/1261.htm', '官方/文旅集团'),
    'baidu_exp': ('百度经验：鲁迅故里简介', 'https://jingyan.baidu.com/article/7082dc1c12e154a50a89bd84.html', '百度系/第三方经验'),
    'baike_tashuo_scenic': ('百度百科TA说：鲁迅故里景区相关介绍', 'https://wapbaike.baidu.com/tashuo/browse/content?id=c88e91fe52b9171a8590dbcf', '百度系/百科TA说'),
    'baike_tashuo_museum': ('百度百科TA说：绍兴鲁迅故里：鲁迅纪念馆', 'https://wapbaike.baidu.com/tashuo/browse/content?id=eba29de29a18b9c00314e06a', '百度系/百科TA说'),
    'baike_tashuo_text': ('百度百科TA说：鲁迅《从百草园到三味书屋》相关介绍', 'https://wapbaike.baidu.com/tashuo/browse/content?id=69372428caa32b08a038476e', '百度系/百科TA说'),
    'shaoxing_news_hours': ('绍兴网：鲁迅故里景区开放时间调整公告', 'https://www.shaoxing.com.cn/p/3384879.html', '地方媒体/公告转载'),
    'sx_gov_traffic': ('绍兴市政府相关页面：附近地铁与公交信息', 'https://www.sx.gov.cn/art/2024/7/3/art_1229365388_59542165.html', '政府信息'),
    'zj_ct': ('浙江省文化和旅游厅：Lu Xun Native Place', 'https://ct.zj.gov.cn/art/2019/8/5/art_1672758_36392457.html', '政府文旅'),
    'bendibao': ('绍兴本地宝：鲁迅故里游玩攻略', 'https://sx.bendibao.com/tour/2023621/20696.shtm', '本地生活/攻略'),
    'xianheng': ('绍兴咸亨集团：咸亨酒店信息', 'https://www.xianheng.com/index.php?a=lists&c=index&catid=151&m=content', '企业官方'),
    'ctrip_food': ('携程美食：咸亨酒店菜品参考', 'https://you.ctrip.com/food/18/7833129.html', '旅游平台'),
    'klook_hotel': ('Klook酒店页：鲁迅故里沈园周边住宿参考', 'https://www.klook.com/zh-CN/hotels/detail/1993761-shaoxing-dayue-xiaoyuan-culture-theme-hotel-lu-xuns-hometown-shenyuan-branch/', '旅游平台'),
    'huazhu_hotel': ('华住会：汉庭绍兴鲁迅故里酒店', 'https://m.huazhu.com/Hotel/Detail/9019177', '酒店官方平台'),
    'amap_bus': ('高德地图：鲁迅故里公交站信息', 'https://www.amap.com/place/BV10198907', '地图平台'),
}

def src(keys):
    names, urls = [], []
    for k in keys:
        names.append(sources[k][0])
        urls.append(sources[k][1])
    return '；'.join(names), '；'.join(urls)

summary_rows = []
def add_summary(category, item, content, keywords, keys, note=''):
    sname, surl = src(keys)
    summary_rows.append([category, item, content, keywords, sname, surl, note])

add_summary('景区基本信息', '名称与定位', '鲁迅故里景区/绍兴鲁迅故里景区位于浙江省绍兴市越城区鲁迅中路235号一带，是鲁迅先生诞生和青少年时期生活过的故土，也是绍兴市区保存完好、文化内涵丰富、体现水城经典风貌的历史街区。', '鲁迅故里；绍兴；历史街区；鲁迅中路235号', ['official_intro','sx_tour_lxgl','sx_tour_area'])
add_summary('景区基本信息', '景区等级与荣誉', '景区现为国家AAAAA级旅游景区、全国重点文物保护单位、全国爱国主义教育基地/示范基地、全国红色旅游经典景区、全国中小学生研学实践教育基地、首批“全国研学旅游示范基地”之一。', '5A；全国重点文物保护单位；爱国主义教育；红色旅游；研学', ['official_intro','sx_tour_lxgl','sx_tour_area'])
add_summary('景区基本信息', '面积与组成', '绍兴市文化旅游集团资料称，绍兴鲁迅故里景区占地约28.9万平方米，拥有鲁迅故居、百草园、三味书屋、鲁迅祖居、绍兴鲁迅纪念馆、鲁迅笔下风情园等。', '28.9万平方米；鲁迅故居；百草园；三味书屋；鲁迅祖居；纪念馆；风情园', ['sx_tour_lxgl'])
add_summary('景区基本信息', '文化价值', '景区通过一批与鲁迅生平、童年记忆和文学作品密切相关的人文古迹，提供“解读鲁迅作品、品味鲁迅笔下风物、感受鲁迅当年生活情境”的场所。', '鲁迅作品；鲁迅笔下风物；生活情境；文化地标', ['sx_tour_area','sx_tour_lxgl'])
add_summary('历史沿革', '纪念馆建立', '绍兴鲁迅纪念馆始建于1953年，是建国后浙江省较早建立的纪念性人物博物馆之一。', '1953；纪念性人物博物馆', ['sx_tour_area','baidu_exp'])
add_summary('历史沿革', '保护与开放', '百度经验资料称，2003年鲁迅故里保护工程竣工；2008年6月起鲁迅纪念馆实行“文化惠民”工程免费开放；2012年鲁迅故里和沈园景区联手成为绍兴当时唯一一个5A级景区。', '2003；2008；2012；免费开放；5A', ['baidu_exp'], '百度经验为辅助来源，关键出行信息以官方现行公告为准。')
add_summary('主要景点', '鲁迅故居（周家新台门）', '周家新台门位于绍兴城内东昌坊口，建于清嘉庆年间，是周氏家族三个台门中建成较晚的一个。1881年9月25日鲁迅出生于此，并一直生活到18岁去南京求学；新台门坐北朝南，青瓦粉墙，砖木结构，共分六进，大小房屋80余间，连同后面的百草园占地4000余平方米。', '周家新台门；清嘉庆；1881年9月25日；六进；80余间；4000余平方米', ['sx_tour_guzhai','sx_tour_area'])
add_summary('主要景点', '百草园', '百草园原为新台门周家的菜园，占地近2000平方米，是鲁迅幼时游戏玩耍之处。鲁迅成年后写《从百草园到三味书屋》回忆此地，文中提到的泥墙根和石井至今保存完好。', '百草园；菜园；童年；从百草园到三味书屋；泥墙根；石井；近2000平方米', ['sx_tour_area','baidu_exp'])
add_summary('主要景点', '三味书屋（寿家台门）', '寿家台门建于清嘉庆年间，前临小河，与周家老台门隔河相望；东侧厢房即三味书屋。三味书屋是当时绍兴城中有名私塾，鲁迅12岁至17岁在此读书，书屋约35平方米，悬有梁同书所题“三味书屋”匾额，陈设保留塾师讲台、学生座位等传统私塾格局。', '寿家台门；三味书屋；清嘉庆；鲁迅12-17岁；私塾；梁同书；35平方米', ['sx_tour_sanwei','sx_tour_area'])
add_summary('主要景点', '鲁迅祖居（周家老台门）', '鲁迅祖居又称周家老台门，是周氏祖先居住地，位于鲁迅故里景区内，与三味书屋等景点共同构成鲁迅家族与绍兴传统台门生活空间的展示。', '鲁迅祖居；周家老台门；周氏祖先；台门建筑', ['official_visit','sx_tour_area'])
add_summary('主要景点', '绍兴鲁迅纪念馆', '绍兴鲁迅纪念馆始建于1953年。新建纪念馆位于鲁迅故里东侧，东接鲁迅祖居，西邻周家新台门，北毗朱家台门，南临东昌坊口；总占地面积约6000平方米，总建筑面积约5000平方米，以“老房子、新空间”的设计理念与传统街巷肌理保持统一。', '绍兴鲁迅纪念馆；1953；6000平方米；5000平方米；老房子新空间', ['sx_tour_area'])
add_summary('主要景点', '鲁迅笔下风情园（朱家台门）', '朱家台门位于百草园旁，是古城保存较完整的典型花园式台门，修缮后辟为“鲁迅笔下风情园”。台门内有百年罗汉松、盘槐、红梅、绿萼梅等花木，以及约400平方米水池；相关资料称其原为越王望花宫故址。', '鲁迅笔下风情园；朱家台门；花园式台门；百草园旁；400平方米水池', ['sx_tour_area'])
add_summary('特色体验', '研学活动', '景区多年打造“研学旅游先锋基地”，“三味早读”“水乡社戏”“祝福大典”等活动受游客欢迎；三味书屋——鲁迅故里研学游包含鲁迅作品展示课、历史文化体验课、三味早读情景课，并引入版画拓印、木刻藏书票等互动项目。', '研学；三味早读；水乡社戏；祝福大典；版画拓印；木刻藏书票', ['sx_tour_lxgl'])
add_summary('特色体验', '水乡与台门风貌', '景区集中呈现绍兴传统台门建筑、水乡街巷和鲁迅笔下风物，适合结合鲁迅作品文本、绍兴古城风貌、江南水乡空间进行文化游览。', '台门；水乡；鲁迅作品；绍兴古城', ['sx_tour_area','sx_tour_lxgl'])
add_summary('开放预约', '开放时间', '官方参观指南显示：周一8:30-17:00（16:30停止预约、16:45停止入园）；周二至周日8:30-21:00（20:00停止预约、20:30停止入园）；黄金周、小长假8:30-22:30（21:30停止预约、22:00停止入园），周一逢黄金周/小长假亦按该时间执行。', '开放时间；停止预约；停止入园；黄金周', ['official_visit','shaoxing_news_hours'], '出行前建议复核官方公众号/官网公告。')
add_summary('开放预约', '开放景点', '官方参观指南列出的开放景点包括鲁迅祖居、三味书屋、鲁迅纪念馆（页面标注“封闭提升中”）、鲁迅故居、百草园、鲁迅笔下风情园；17:00以后出于游览安全，部分假山、水域等区域关闭。', '开放景点；纪念馆封闭提升中；17:00后部分区域关闭', ['official_visit'], '“封闭提升中”为抓取时页面显示，需以实时公告为准。')
add_summary('开放预约', '门票与预约', '景区实行“限量、预约、错峰”；参观需提前关注“绍兴市文旅集团”或“绍兴鲁迅纪念馆”官方微信账号分时预约。预约成功后，在预约时间段内凭身份证或人脸识别进入各景点；错过预约时间段需重新预约。官方提示认准官方渠道免费预约，勿购买非官方渠道门票。', '免费预约；分时预约；身份证；人脸识别；官方微信', ['official_visit','shaoxing_news_hours'])
add_summary('开放预约', '预约限制与咨询', '官方参观指南提示使用实名注册手机号码预约；每个手机号码每天只能预约一次，每次最多预约5人。咨询电话：0575-85132080。', '实名；每天一次；最多5人；0575-85132080', ['official_visit'])
add_summary('交通', '地址', '鲁迅故里景区地址常见官方标注为浙江省绍兴市越城区鲁迅中路235号；官方页也描述为解放路、中兴路与鲁迅路交叉口附近。', '鲁迅中路235号；越城区；解放路；中兴路', ['official_visit','sx_tour_lxgl','zj_ct'])
add_summary('交通', '轨道交通', '绍兴市政府相关页面显示，附近地铁站为绍兴轨道交通1号线“鲁迅故里站”，步行约290米可达；适合从绍兴北站、绍兴站等换乘进入古城。', '地铁1号线；鲁迅故里站；步行约290米', ['sx_gov_traffic'])
add_summary('交通', '公交', '可关注“鲁迅故里”或“塔山（地铁鲁迅故里站）”附近公交站。搜索结果显示鲁迅故里公交站有8路、8A路、13路、13A路、24路、24A路、30路、52路、52A路、68路、88路、111路、177路、快70路、快88路、古城公交接驳专线等线路；塔山站也有5路、60路、60A路、9路、11路、2路、4路东环等。', '公交；鲁迅故里站；塔山站；古城公交接驳', ['amap_bus','sx_gov_traffic'], '公交线路会调整，出发前以地图/公交实时信息为准。')
add_summary('住宿', '住宿区域建议', '若以步行游览为主，可优先选择鲁迅中路、马园弄、沈园、人民路、解放路、仓桥直街一带住宿；这些区域便于串联鲁迅故里、沈园、仓桥直街及古城餐饮。', '鲁迅中路；沈园；人民路；仓桥直街；步行游览', ['klook_hotel','huazhu_hotel'])
add_summary('住宿', '周边酒店参考', '检索到的周边住宿包括绍兴大越小院文化主题酒店（鲁迅故里沈园店，页面显示距鲁迅故里约300米）、汉庭绍兴鲁迅故里酒店（华住页面显示距鲁迅故里/沈园步行约7分钟）等；房价和房态需实时查询。', '大越小院；汉庭；鲁迅故里沈园；周边住宿', ['klook_hotel','huazhu_hotel'], '酒店仅作区域参考，不构成预订推荐。')
add_summary('美食', '绍兴风味', '鲁迅故里周边可重点体验绍兴黄酒、茴香豆、臭豆腐、梅干菜扣肉、醉鸡、醉虾/生醉河虾、醉鱼干、熏鱼、油焖笋等绍兴风味。', '黄酒；茴香豆；臭豆腐；梅干菜扣肉；醉鸡；醉虾；熏鱼；油焖笋', ['xianheng','ctrip_food'])
add_summary('美食', '咸亨酒店', '咸亨集团资料显示，咸亨酒店创始于1894年，位于浙江省绍兴市鲁迅中路179号；因鲁迅作品与绍兴风味体验，游客常将其与鲁迅故里游览结合。旅游平台常见菜品包括茴香豆、炸臭豆腐、霉干菜红烧肉、醉鸡、生醉河虾、熏鱼、油焖笋等。', '咸亨酒店；1894；鲁迅中路179号；茴香豆；绍兴黄酒', ['xianheng','ctrip_food'])
add_summary('游览建议', '推荐路线', '可按“鲁迅故里入口—鲁迅祖居—三味书屋—鲁迅故居/百草园—鲁迅笔下风情园—绍兴鲁迅纪念馆（如开放）—沈园/仓桥直街”顺序游览；若带学生研学，可把三味书屋、百草园和鲁迅作品文本结合。', '游览路线；入口；祖居；三味书屋；百草园；风情园；沈园；仓桥直街', ['sx_tour_area','official_visit','bendibao'])
add_summary('游览建议', '时间安排', '鲁迅故里核心景点可安排约2-3小时；若叠加沈园、仓桥直街、用餐和夜游，可安排半天到一天。节假日需更早预约并预留排队时间。', '2-3小时；半天；一天；节假日；预约', ['bendibao','official_visit'])

spot_rows = []
def add_spot(name, alias, typ, location, history, highlights, relation, tip, keys):
    sname, surl = src(keys)
    spot_rows.append([name, alias, typ, location, history, highlights, relation, tip, sname, surl])

add_spot('鲁迅故里景区', '绍兴鲁迅故里景区；鲁迅故里·沈园景区组成部分', '历史文化街区/5A景区', '绍兴市越城区鲁迅中路235号一带', '鲁迅诞生并度过青少年时期的故土；街区保存绍兴水城风貌和传统台门空间。', '鲁迅故居、百草园、三味书屋、鲁迅祖居、绍兴鲁迅纪念馆、鲁迅笔下风情园等。', '集中对应鲁迅童年、家族生活、求学经历和多篇作品中的绍兴风物。', '适合作为绍兴古城文化游首站；需提前预约。', ['official_intro','sx_tour_lxgl','official_visit'])
add_spot('鲁迅故居', '周家新台门', '故居/台门建筑', '绍兴城内东昌坊口；与百草园相连', '建于清嘉庆年间；1881年9月25日鲁迅出生于此，生活到18岁赴南京求学，后回乡任教也多居于此。', '青瓦粉墙、砖木结构、坐北朝南；六进院落、大小房屋80余间；连同百草园占地4000余平方米。', '鲁迅童年、少年生活空间，是理解其家庭背景和绍兴生活经验的重要地点。', '与百草园连看，适合对照《从百草园到三味书屋》阅读。', ['sx_tour_guzhai','sx_tour_area'])
add_spot('百草园', '新台门周家菜园', '园地/文学场景', '鲁迅故居后面', '原为新台门周氏族人共有菜园，平时种瓜菜，秋后晒稻谷，占地近2000平方米。', '泥墙根、石井等文中意象保存；园地呈现鲁迅童年玩耍空间。', '鲁迅散文《从百草园到三味书屋》的核心场景之一，被称作童年“乐园”。', '适合与课文内容、童年自然观察主题结合讲解。', ['sx_tour_area','baidu_exp'])
add_spot('三味书屋', '寿家台门东侧厢房', '私塾/教育场景', '寿家台门内，前临小河，与周家老台门隔河相望', '寿家台门建于清嘉庆年间；三味书屋为绍兴城内颇有名私塾，鲁迅12岁至17岁在此读书。', '书屋约35平方米；悬梁同书题“三味书屋”匾；下挂《松鹿图》；保留塾师讲台、学生座位、对联等陈设。', '对应《从百草园到三味书屋》中“出门向东，不上半里……”等描写，体现鲁迅早年私塾教育经历。', '团队多，可错峰进入室内；注意保护文物陈设。', ['sx_tour_sanwei','sx_tour_area'])
add_spot('鲁迅祖居', '周家老台门', '祖居/台门建筑', '鲁迅故里景区内，与三味书屋隔河相望区域', '周氏祖先居住地，是展示鲁迅家族世系、绍兴台门建筑和传统家族生活的重要空间。', '传统台门格局、家族生活展示、与周家新台门形成家族居住空间对照。', '帮助理解鲁迅家族背景、绍兴士绅家庭生活与地方文化。', '可与故居合并讲解“老台门/新台门”的家族空间关系。', ['official_visit','sx_tour_area'])
add_spot('绍兴鲁迅纪念馆', '鲁迅生平事迹陈列相关空间', '纪念馆/人物博物馆', '鲁迅故里东侧；东接鲁迅祖居、西邻周家新台门、北毗朱家台门、南临东昌坊口', '始建于1953年；2003年前后为恢复故里传统风貌，新建纪念馆以“老房子、新空间”理念融入传统街巷肌理。', '总占地约6000平方米、总建筑面积约5000平方米；展示鲁迅生平业绩及其与故乡绍兴的渊源。', '系统了解鲁迅思想、文学、人生经历及绍兴文化背景。', '官方参观指南抓取时标注“封闭提升中”，参观前务必确认是否开放。', ['sx_tour_area','official_visit'])
add_spot('鲁迅笔下风情园', '朱家台门', '花园式台门/风情展示', '百草园旁', '朱家台门修缮后辟为鲁迅笔下风情园；资料称其原为越王望花宫故址，明初名将胡大海官宅的一部分。', '典型花园式台门；百年罗汉松、盘槐、红梅、绿萼梅等花木；约400平方米水池。', '通过绍兴台门、花木、水池和地方风情补充鲁迅笔下绍兴生活图景。', '适合补充拍照与民俗/风物讲解；夜间或17:00后部分水域假山区可能关闭。', ['sx_tour_area','official_visit'])
add_spot('鲁迅故里步行街/风情街', '鲁迅中路历史街区商业与游览空间', '历史街区/步行游览', '鲁迅中路及景点周边', '依托鲁迅故里历史街区与绍兴传统街巷形成游览动线。', '沿线可串联景点、文创、绍兴小吃、黄酒体验、咸亨酒店等。', '作为鲁迅故里景区外延体验，连接文学记忆、绍兴生活和当代旅游消费。', '商业信息变化快，建议以现场和地图为准；避免把商户宣传当作史实。', ['sx_tour_lxgl','xianheng','ctrip_food'])

practical_rows = [
    ['开放时间', '周一', '8:30-17:00；16:30停止预约，16:45停止入园。', '逢黄金周、小长假按假日时间执行。', *src(['official_visit'])],
    ['开放时间', '周二至周日', '8:30-21:00；20:00停止预约，20:30停止入园。', '出行前查官方公告。', *src(['official_visit','shaoxing_news_hours'])],
    ['开放时间', '黄金周/小长假', '8:30-22:30；21:30停止预约，22:00停止入园。', '周一逢黄金周/小长假亦按此开放时间执行。', *src(['official_visit','shaoxing_news_hours'])],
    ['预约', '预约渠道', '关注“绍兴市文旅集团”或“绍兴鲁迅纪念馆”官方微信账号，进行分时预约。', '官方提示免费预约，勿购买非官方渠道门票。', *src(['official_visit'])],
    ['预约', '入园凭证', '预约成功后在预约时间段内凭身份证或人脸识别进入各景点；错过时段需重新预约。', '使用人脸识别需预约时同步录入。', *src(['official_visit'])],
    ['预约', '人数限制', '实名注册手机号码预约；每个手机号每天只能预约一次，每次最多预约5人。', '团队/家庭需提前规划多个实名预约。', *src(['official_visit'])],
    ['咨询', '咨询电话', '0575-85132080；绍兴市文化旅游集团页面另列旅游咨询电话0575-85081706。', '以官方最新公示为准。', *src(['official_visit','sx_tour_lxgl'])],
    ['文明游览', '注意事项', '景区为无烟景区；请勿挪动展品，爱护公共设施；禁止嬉水、攀爬假山树木；严禁携带宠物入园。', '儿童、行动不便老人需陪同。', *src(['official_visit'])],
    ['游览组合', '半日路线', '鲁迅祖居—三味书屋—鲁迅故居—百草园—鲁迅笔下风情园—绍兴鲁迅纪念馆（如开放）。', '适合2-3小时核心游。', *src(['sx_tour_area','official_visit'])],
    ['游览组合', '一日路线', '上午鲁迅故里核心景点，中午鲁迅中路/咸亨酒店周边用餐，下午沈园或仓桥直街，晚上可考虑夜游/古城散步。', '节假日注意预约与排队。', *src(['bendibao','xianheng'])],
]

travel_rows = []
def add_travel(cat, name, content, advice, keys):
    sname, surl = src(keys)
    travel_rows.append([cat, name, content, advice, sname, surl])

add_travel('交通', '地铁', '绍兴轨道交通1号线“鲁迅故里站”临近景区，绍兴市政府页面显示步行约290米可达。', '优先推荐公共交通进入古城，避开核心区停车压力。', ['sx_gov_traffic'])
add_travel('交通', '公交', '可搜索“鲁迅故里”“塔山（地铁鲁迅故里站）”等站点。地图检索显示多条公交线路途经，包括8、13、24、30、52、68、88、111、177路及古城公交接驳专线等。', '公交线路会调整，出发当天以地图/公交APP为准。', ['amap_bus','sx_gov_traffic'])
add_travel('交通', '自驾/停车', '鲁迅故里位于古城核心区，节假日车流、人流集中；本地攻略提到可关注绍兴古城停车场等周边停车资源。', '自驾建议提前查停车场余位，尽量错峰。', ['bendibao'])
add_travel('住宿', '鲁迅中路/马园弄/沈园周边', '距离鲁迅故里和沈园近，适合步行为主、首次到绍兴的游客。', '价格通常随节假日波动，提前预订。', ['klook_hotel'])
add_travel('住宿', '人民路/解放路/仓桥直街周边', '兼顾古城餐饮、步行游览与交通，适合想把鲁迅故里、仓桥直街、城市漫步结合的游客。', '可比较连锁酒店与精品民宿，注意噪音和停车条件。', ['huazhu_hotel'])
add_travel('住宿', '酒店示例', '绍兴大越小院文化主题酒店（鲁迅故里沈园店）页面显示距鲁迅故里约300米；汉庭绍兴鲁迅故里酒店页面显示距鲁迅故里、沈园步行约7分钟。', '示例只作地理参考，实际以平台实时价格、评价和房态为准。', ['klook_hotel','huazhu_hotel'])
add_travel('美食', '咸亨酒店', '咸亨集团资料显示咸亨酒店创始于1894年，地址为绍兴市鲁迅中路179号。', '可作为鲁迅故里游后的绍兴风味体验点，高峰期可能排队。', ['xianheng'])
add_travel('美食', '经典绍兴味', '常见特色包括绍兴黄酒、茴香豆、炸臭豆腐、梅干菜扣肉、醉鸡、生醉河虾、熏鱼、油焖笋、醉鱼干等。', '口味偏咸鲜/酒香，不能饮酒者注意菜品含酒。', ['ctrip_food','xianheng'])
add_travel('美食', '街区小吃与文创', '鲁迅中路历史街区和景区周边有小吃、文创、黄酒体验等商业内容。', '商户更新快，建议现场比价，避免把营销话术当作历史事实。', ['sx_tour_lxgl','ctrip_food'])

baidu_rows = [
    ['百度经验', '鲁迅故里简介', '页面概述鲁迅故里位于浙江省绍兴市鲁迅中路；1953年1月绍兴鲁迅纪念馆成立；2003年保护工程竣工；2008年6月起免费开放；并分述百草园、三味书屋、鲁迅祖居。', sources['baidu_exp'][1], '作为百度系资料纳入；与官方来源交叉核验后使用。'],
    ['百度经验', '百草园摘录', '称百草园在鲁迅故居后面，占地近2000平方米，原为新台门周姓住户共有菜园，主要部分仍基本保持原样。', sources['baidu_exp'][1], '与绍兴文旅集团页面一致。'],
    ['百度经验', '三味书屋摘录', '称三味书屋是绍兴城内私塾，鲁迅12岁开始到此读书，前后约五年，书屋约35平方米，匾额为清代书法家梁同书所题。', sources['baidu_exp'][1], '与绍兴文旅集团三味书屋页一致。'],
    ['百度经验', '鲁迅祖居摘录', '称鲁迅祖居为周家老台门，坐北朝南，前临东昌坊口，后通咸欢河，西接戴家台门，与三味书屋隔河相望。', sources['baidu_exp'][1], '具体空间描述可作补充，建议以现场导览为准。'],
    ['百度百科TA说', '鲁迅故里景区相关介绍', '搜索结果显示该页描述鲁迅故里景区为鲁迅少年时生活、学习相关场所，涉及鲁迅故居、百草园、三味书屋等。', sources['baike_tashuo_scenic'][1], '抓取时遇到百度验证页，未完整抽取正文；作为检索来源记录。'],
    ['百度百科TA说', '绍兴鲁迅故里：鲁迅纪念馆', '搜索结果显示该页介绍绍兴鲁迅故里是鲁迅青少年时期生活过的故土，包含鲁迅故居、鲁迅祖居、百草园、三味书屋等相关内容。', sources['baike_tashuo_museum'][1], '抓取受限，仅保留搜索结果摘要。'],
    ['百度百科TA说', '从百草园到三味书屋相关', '搜索结果显示该页围绕鲁迅散文《从百草园到三味书屋》背景，涉及百草园、三味书屋和鲁迅童年经历。', sources['baike_tashuo_text'][1], '用于文学背景线索；事实以官方景区页核验。'],
]

cleaning_rows = [
    ['抓取范围', '围绕“鲁迅故里景区（绍兴）”收集景区基本介绍、分景点、历史、特色体验、开放预约、交通、住宿、美食和游览建议。'],
    ['清理规则', '删除网页导航、版权栏、重复标题、广告推荐、无关景点内容；保留可核验的时间、地点、名称、面积、历史节点、开放规则等事实信息。'],
    ['来源优先级', '官方景区官网、绍兴市文化旅游集团官网、政府/文旅部门信息优先；百度经验/百度百科TA说、旅游平台用于补充，并在备注中标明。'],
    ['时效提示', f'本表整理日期为{SCRAPE_DATE}。开放时间、预约规则、纪念馆开放状态、公交线路、酒店房态和商户菜单均可能变化，出行前应复核官方公众号、官网或实时地图/预订平台。'],
    ['深度研究说明', '已尝试运行 deep-research 工作流，但该工作流本次未能抽取有效 claims；随后改用本地 requests/BeautifulSoup 抓取官方页面，并结合网页搜索结果补充交通、住宿、美食来源。'],
]

source_rows = []
for i, (key, (name, url, typ)) in enumerate(sources.items(), start=1):
    if key in ['official_intro','official_visit','sx_tour_area','sx_tour_lxgl','sx_tour_sanwei','sx_tour_guzhai']:
        reliability = '高：官方/文旅集团页面，作为主要事实来源'
    elif key in ['sx_gov_traffic','zj_ct','shaoxing_news_hours']:
        reliability = '较高：政府/地方媒体公告信息'
    elif key.startswith('baidu'):
        reliability = '中：百度系内容，作为补充或线索，已尽量与官方交叉核验'
    else:
        reliability = '中：旅游/地图/企业平台，适合补充交通、住宿、美食等动态信息'
    source_rows.append([i, name, typ, url, reliability])

wb = Workbook()
wb.remove(wb.active)

def add_sheet(title, headers, rows):
    ws = wb.create_sheet(title)
    ws.append(headers)
    for row in rows:
        ws.append(row)
    # style header
    header_fill = PatternFill('solid', fgColor='1F4E78')
    header_font = Font(color='FFFFFF', bold=True)
    thin = Side(style='thin', color='D9E2F3')
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = Border(top=thin, left=thin, right=thin, bottom=thin)
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical='top', wrap_text=True)
            cell.border = Border(top=thin, left=thin, right=thin, bottom=thin)
    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = ws.dimensions
    # dimensions
    for col_idx in range(1, ws.max_column + 1):
        letter = get_column_letter(col_idx)
        max_len = 0
        for cell in ws[letter]:
            value = '' if cell.value is None else str(cell.value)
            max_len = max(max_len, min(len(value), 80))
        if col_idx in [3,5,6,7,8,9,10]:
            width = min(max(max_len + 2, 18), 60)
        else:
            width = min(max(max_len + 2, 10), 32)
        ws.column_dimensions[letter].width = width
    ws.sheet_view.showGridLines = False
    return ws

add_sheet('01_分类总表', ['信息类别','条目','清理后内容','关键词','来源名称','来源链接','备注'], summary_rows)
add_sheet('02_景点详情', ['景点名称','别名/关联','类型','位置/范围','历史与背景','主要看点','与鲁迅/作品关系','游览提示','来源名称','来源链接'], spot_rows)
add_sheet('03_参观实用信息', ['类别','项目','内容','适用对象/备注','来源名称','来源链接'], practical_rows)
add_sheet('04_交通住宿美食', ['类别','名称/区域','内容','建议','来源名称','来源链接'], travel_rows)
add_sheet('05_百度相关资料', ['百度来源类型','主题','整理内容','链接','处理备注'], baidu_rows)
add_sheet('06_来源清单', ['序号','来源名称','来源类型','URL','可信度/使用说明'], source_rows)
add_sheet('07_抓取清理说明', ['项目','说明'], cleaning_rows)

# Add hyperlinks where cells contain single URL; keep multi-URL as text to avoid broken link handling.
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for cell in row:
            if isinstance(cell.value, str) and cell.value.startswith('http') and '；' not in cell.value:
                cell.hyperlink = cell.value
                cell.style = 'Hyperlink'

# Add Excel tables for readability where possible
for ws in wb.worksheets:
    if ws.max_row > 1 and ws.max_column > 1:
        ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"
        display_name = 'T_' + ''.join(ch if ch.isalnum() else '_' for ch in ws.title)[:20]
        table = Table(displayName=display_name, ref=ref)
        style = TableStyleInfo(name='TableStyleMedium2', showFirstColumn=False, showLastColumn=False, showRowStripes=True, showColumnStripes=False)
        table.tableStyleInfo = style
        ws.add_table(table)

# Cover sheet
cover = wb.create_sheet('00_使用说明', 0)
cover_rows = [
    ['文件名', OUTPUT],
    ['整理主题', '鲁迅故里景区（绍兴）文字信息抓取、清理与分类整理'],
    ['整理日期', SCRAPE_DATE],
    ['主要内容', '基本介绍、景点详情、特色历史、开放预约、交通、住宿、美食、游览建议、百度相关资料、来源清单。'],
    ['重要提示', '开放时间、预约规则、纪念馆是否开放、公交线路、酒店房态和餐饮菜单会变化；实际出行请以官方公众号/官网及实时平台为准。'],
]
for row in cover_rows:
    cover.append(row)
cover['A1'].font = Font(bold=True)
for row in cover.iter_rows():
    for cell in row:
        cell.alignment = Alignment(vertical='top', wrap_text=True)
cover.column_dimensions['A'].width = 16
cover.column_dimensions['B'].width = 100
cover.sheet_view.showGridLines = False

wb.save(OUTPUT)
print(OUTPUT)
print('sheets:', ', '.join(wb.sheetnames))
print('rows:', {ws.title: ws.max_row for ws in wb.worksheets})
