# -*- coding: utf-8 -*-
"""
Fix 05_实用信息 sheet:
  1. 美食栏 咸亨酒店 -> 咸亨酒店菜品
  2. 备注栏(I列) 原为一个 I2:I62 合并单元格(内容是重复拼接的脏数据)，
     拆成与每一行 一一对应 的独立备注单元格
  3. 去掉 "由07小红书数据汇总分发补充" 等内部字眼
"""
import re
from copy import copy
import openpyxl

PATH = r"D:\python学习\baidupc\鲁迅故里景区资料整理_最终版.xlsx"
SHEET = "05_实用信息"
REMARK_COL = 9  # I
ITEM_COL = 2    # B

XHS_PHRASE = "由07小红书数据汇总分发补充"


def clean_value(v: str, key: str) -> str:
    """Clean a single remark value."""
    if v is None:
        return ""
    s = str(v)
    # 去掉开头的 项目名： 重复前缀(生成时 entry0 的 glitch)
    if s.startswith(key + "："):
        s = s[len(key) + 1:]
    # 去掉 "由07小红书数据汇总分发补充" 及随后的分隔符
    s = re.sub(re.escape(XHS_PHRASE) + r"[；;]?", "", s)
    s = s.replace(XHS_PHRASE, "")
    # 去掉因删除产生的行首多余分隔符 / 空白
    s = s.lstrip("；; \t")
    return s.strip()


def build_remark_map(raw: str) -> dict:
    """Parse the giant merged cell text; keep the FIRST clean value per key."""
    m = {}
    for ln in str(raw).split("\n"):
        if "：" not in ln:
            continue
        key, val = ln.split("：", 1)
        key = key.strip()
        if not key or key in m:
            continue  # 保留首个(干净)值, 忽略后续重复/错位块
        cleaned = clean_value(val, key)
        if cleaned:
            m[key] = cleaned
    return m


def main():
    wb = openpyxl.load_workbook(PATH)
    ws = wb[SHEET]

    raw = ws.cell(row=2, column=REMARK_COL).value
    remark_map = build_remark_map(raw)
    print("parsed distinct remark keys:", len(remark_map))

    # 1) 取消 I2:I62 合并
    merge_target = "I2:I62"
    present = [str(r) for r in ws.merged_cells.ranges]
    if merge_target in present:
        ws.unmerge_cells(merge_target)
        print("unmerged", merge_target)
    else:
        print("WARN: I2:I62 not found in merges:", present)

    # 备注列样式(沿用原 I2: 细边框 + 左上对齐 + 自动换行)
    style_src = ws.cell(row=2, column=REMARK_COL)
    src_font = copy(style_src.font)
    src_border = copy(style_src.border)
    src_fill = copy(style_src.fill)
    src_align = copy(style_src.alignment)

    missing = []
    for r in range(2, 63):
        item = ws.cell(row=r, column=ITEM_COL).value
        cell = ws.cell(row=r, column=REMARK_COL)
        remark = remark_map.get(str(item).strip())
        if remark is None:
            missing.append((r, item))
            remark = ""
        cell.value = remark
        cell.font = copy(src_font)
        cell.border = copy(src_border)
        cell.fill = copy(src_fill)
        cell.alignment = copy(src_align)

    if missing:
        print("WARN rows without remark:", missing)
    else:
        print("all 61 rows mapped one-to-one OK")

    # 2) 美食栏 咸亨酒店 -> 咸亨酒店菜品
    b23 = ws.cell(row=23, column=ITEM_COL)
    print("B23 before:", repr(b23.value))
    assert b23.value == "咸亨酒店", f"expected 咸亨酒店, got {b23.value!r}"
    b23.value = "咸亨酒店菜品"
    print("B23 after :", repr(b23.value))

    wb.save(PATH)
    print("saved:", PATH)


if __name__ == "__main__":
    main()
