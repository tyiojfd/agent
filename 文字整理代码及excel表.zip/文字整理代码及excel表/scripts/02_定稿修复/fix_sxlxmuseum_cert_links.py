from openpyxl import load_workbook

INPUT = r'D:\python学习\baidupc\鲁迅故里景区资料整理_最终版.xlsx'
OUTPUT = r'D:\python学习\baidupc\鲁迅故里景区资料整理_最终版_网址修正.xlsx'

OLD_PATTERNS = [
    'https://sxlxmuseum.com/',
    'https://www.sxlxmuseum.com/',
]
NEW = 'http://sxlxmuseum.com/'

wb = load_workbook(INPUT)
replaced = 0

for ws in wb.worksheets:
    for row in ws.iter_rows():
        for cell in row:
            if isinstance(cell.value, str):
                value = cell.value
                new_value = value
                for old in OLD_PATTERNS:
                    if old in new_value:
                        new_value = new_value.replace(old, NEW)
                if new_value != value:
                    cell.value = new_value
                    replaced += 1
            if cell.hyperlink and cell.hyperlink.target:
                target = cell.hyperlink.target
                new_target = target
                for old in OLD_PATTERNS:
                    if old in new_target:
                        new_target = new_target.replace(old, NEW)
                if new_target != target:
                    cell.hyperlink = new_target
                    replaced += 1

# Update notes in cover/cleaning sheets if present.
if '00_使用说明' in wb.sheetnames:
    ws = wb['00_使用说明']
    next_row = ws.max_row + 1
    ws.cell(next_row, 1).value = '链接修正'
    ws.cell(next_row, 2).value = '因 sxlxmuseum.com 官方站 HTTPS 证书域名不匹配，浏览器会提示“你的连接不是专用连接”。本版已将该官方站链接统一改为 http://sxlxmuseum.com/ 开头，避免证书错误。'

if '08_抓取清理说明' in wb.sheetnames:
    ws = wb['08_抓取清理说明']
    next_row = ws.max_row + 1
    ws.cell(next_row, 1).value = '官网证书链接修正'
    ws.cell(next_row, 2).value = '绍兴鲁迅故里沈园景区官网 sxlxmuseum.com 的 HTTPS 证书存在域名不匹配问题（net::ERR_CERT_COMMON_NAME_INVALID），但 HTTP 页面可正常访问；因此本表将该站点来源链接改为 HTTP 版本。'

wb.save(OUTPUT)
print(OUTPUT)
print('replaced_cells_or_targets:', replaced)
